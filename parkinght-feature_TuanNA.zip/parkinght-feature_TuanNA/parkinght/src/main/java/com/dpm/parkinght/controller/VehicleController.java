package com.dpm.parkinght.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dpm.parkinght.common.BaseResponse;
import com.dpm.parkinght.dto.entity.Vehicle;
import com.dpm.parkinght.dto.request.VehicleCreateRequest;
import com.dpm.parkinght.dto.request.VehicleUpdateRequest;
import com.dpm.parkinght.service.VehicleService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/vehicle")
//@RequiredArgsConstructor
public class VehicleController {
    //	@Autowired
    private final VehicleService vehicleService;

    @Autowired
    public VehicleController(VehicleService vehicleService) {
        this.vehicleService = vehicleService;
    }

    @GetMapping("/get-all")
    public BaseResponse<List<Vehicle>> getAll(Principal principal) {
        return BaseResponse.ok(vehicleService.getAll(principal));
    }

    @PostMapping("/create")
    public BaseResponse<?> createVehicle(@Valid @RequestBody VehicleCreateRequest request, Principal principal) {
        return BaseResponse.ok(vehicleService.save(request, principal));
    }

    @GetMapping("/get-by-id/{id}")
    public BaseResponse<?> getById(Principal principal, @PathVariable("id") String id) {
        return BaseResponse.ok(vehicleService.findById(principal, id));
    }


    @PutMapping("/delete/{id}")
    public BaseResponse<?> delete(Principal principal, @PathVariable("id") String id) {
        return BaseResponse.ok(vehicleService.deleteVehicle(principal, id));
    }

    @PutMapping("/update")
    public BaseResponse<?> update(@Valid @RequestBody VehicleUpdateRequest request, Principal principal) {
        return BaseResponse.ok(vehicleService.update(request, principal));
    }

    @GetMapping("/get-by-category/{id}")
    public BaseResponse<?> update(@PathVariable("id") String categoryId, Principal principal) {
        return BaseResponse.ok(vehicleService.getByVehicleCategory(principal, categoryId));
    }
}