package com.dpm.parkinght.service.impl;

import java.security.Principal;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.dto.entity.Booking;
import com.dpm.parkinght.dto.entity.ParkingSlot;
import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.response.IBookingResponse;
import com.dpm.parkinght.enums.Cost;
import com.dpm.parkinght.enums.StatusBooking;
import com.dpm.parkinght.repository.BookingRepository;
import com.dpm.parkinght.repository.ParkingSlotRepository;
import com.dpm.parkinght.repository.UserRepository;
import com.dpm.parkinght.service.BookingService;
import com.dpm.parkinght.service.UserService;
import com.twilio.rest.api.v2010.account.availablephonenumbercountry.Local;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class BookingServiceImpl implements BookingService {

	private final BookingRepository bookingRepository;
	private final UserRepository userRepository;
	private final UserService userService;
	private final ParkingSlotRepository parkingSlotRepository;

	private final static String SEQUENCE_NUMBER_START = "0000";
	private final static String PREFIX = "BK";

	public BookingServiceImpl(BookingRepository bookingRepository, UserService userService,
			UserRepository userRepository, ParkingSlotRepository parkingSlotRepository) {
		this.bookingRepository = bookingRepository;
		this.userService = userService;
		this.userRepository = userRepository;
		this.parkingSlotRepository = parkingSlotRepository;
	}

	@Override
	public List<Booking> getAll(Principal principal) {
		if (userService.isDriver(principal.getName())) {
			throw new LogicException("Ban khong co quyen de xem");
		}
		return bookingRepository.findAll();
	}

	@Override
	public Booking findByIdForUser(String id, Principal principal) {
		if (!userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		return bookingRepository.findById(id).orElseThrow(() -> new LogicException("Not found booking with id: " + id));
	}

	@Override
	public List<Booking> getBookingByDriver(Principal principal, String driverId) {
		if (!userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		User user = userRepository.findById(driverId)
				.orElseThrow(() -> new LogicException("Not found user with id: " + driverId));
		return bookingRepository.findAllByUser(user);
	}

	@Override
	public List<Booking> getBookingByDriverIsLogin(Principal principal) {
		if (!userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		User user = userService.findByPhone(principal.getName());
		return bookingRepository.findAllByUser(user);
	}

	@Override
	public Booking insertBooking(Booking booking, Principal principal) {
		if (!userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission - Only Driver");
		}
		
		ParkingSlot parkingSlot = parkingSlotRepository.findById(booking.getParkingSlot().getParkingSlotId())
	            .orElseThrow(() -> new LogicException("Not found parking slot with id: " + booking.getParkingSlot().getParkingSlotId()));
		
		boolean validDate = validateBookingDate(booking.getStart_Date(), booking.getEnd_Date());
		if(!validDate) {
			throw new LogicException("Ngay gio khong hop le");
		}
		
		LocalDateTime startDateTime = booking.getStart_Date();
	    LocalDateTime endDateTime = booking.getEnd_Date();
		//setting thong tin cho booking 
		long totalHours = ChronoUnit.HOURS.between(startDateTime, endDateTime);
		long totalStartD = calculateTotalCost(startDateTime, parkingSlot);
	    long totalEndD = calculateTotalCost(endDateTime, parkingSlot);
	    long totalHourTime = totalStartD + totalEndD + (totalHours - 2) * (checkTimeRang(startDateTime, endDateTime)
	    		+ parkingSlot.getPricePerHour().longValue());
	    String bookingId = generateBookingID();
		booking.setBooking_Id(bookingId);
		booking.setBooking_Status(StatusBooking.ONGOING);
		booking.setBooking_Total(totalHourTime);
		booking.setCreate_Date(LocalDateTime.now());
		return bookingRepository.save(booking);
	}

	public boolean checkUniqueBookingID(String id) {
		return (bookingRepository.checkUniqueId(id) > 0);
	}

	public String generateBookingID() {
		String sequenceNum = bookingRepository.getLastBookingId();
		if (Objects.isNull(sequenceNum)) {
			sequenceNum = SEQUENCE_NUMBER_START;
		} else {
			sequenceNum = getSequenceBookingId(sequenceNum);
		}
		String bookingId = PREFIX.concat(sequenceNum);
		while (checkUniqueBookingID(bookingId)) {
			sequenceNum = getSequenceBookingId(sequenceNum);
			bookingId = PREFIX.concat(sequenceNum);
		}
		return bookingId;
	}

	public String getSequenceBookingId(String serialNumber) {
		String lastNum = serialNumber.substring(3);
		int serial = Integer.parseInt(lastNum) + 1;
		return String.format("%04d", serial);
	}

	public Booking findBookingById(String bookingId, Principal principal) {
		if (!userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission - Only Driver");
		}
		User user = userService.findByPhone(principal.getName());
		return bookingRepository.findByBooking_userId(bookingId, user.getUserId());
	}

	@Override
	public Booking cancelBooking(String bookingID, Principal principal) {
		if (!userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission - Only Driver");
		}
		User user = userService.findByPhone(principal.getName());
		Booking booking = bookingRepository.findByBooking_userId(bookingID, user.getUserId());
		if (booking != null) {
			booking.setBooking_Status(StatusBooking.CANCELED);
			return bookingRepository.save(booking);
		} else
			throw new LogicException("Not found booking");
	}

	@Override
	public List<IBookingResponse> getBookingByStatus(String status, String phoneNumber, Principal principal) {
		if (!userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission - Only Driver");
			}
		List<IBookingResponse> bookingListByStatus = bookingRepository.getBookingByStatus(status, phoneNumber, principal);
		return bookingListByStatus;
	}
	
	private boolean validateBookingDate(LocalDateTime startDate, LocalDateTime endDate) {
		if(endDate.isBefore(startDate)||startDate.isBefore(LocalDateTime.now())) {
			return false;
		}
		long totalHours = ChronoUnit.HOURS.between(startDate, endDate);
		if(totalHours<1) {
			return false;
		}
		return true;
	}
	private long checkTimeRang(LocalDateTime startTime, LocalDateTime endTime) {
		if (startTime.getHour() <= 17 && endTime.getHour() > 6) {
			return Cost.PER_HOUR.getValue().longValue();
		}else {
			return Cost.PER_NIGHT.getValue().longValue();
		}
	}

	private long calculateTotalCost(LocalDateTime dateTime, ParkingSlot parkingSlot) {
	    if (dateTime.getHour() > 17 || dateTime.getHour() < 6) {
	        return Cost.PER_NIGHT.getValue().longValue() + parkingSlot.getPricePerHour().longValue();
	    } else {
	        return Cost.PER_HOUR.getValue().longValue() + parkingSlot.getPricePerHour().longValue();
	    }
	}

	@Override
	public void updateCheckinTime(Booking booking, LocalDateTime checkinTime) {
		booking.setCheckin_Time(checkinTime);
		bookingRepository.save(booking);
	}

	@Override
	public void updateCheckoutTime(Booking booking, LocalDateTime checkoutTime) {
		booking.setCheckout_Time(checkoutTime);
		bookingRepository.save(booking);		
	}
}
