package com.dpm.parkinght.enums;

import java.util.Arrays;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum StatusParkingSlot {

	 BUSY("0", "Busy"), AVAILABLE("1", "Available");

	private String value;
	private String display;

	public String getValue() {
		return value;
	}

	public String getDisplay() {
		return display;
	}
	
	public static StatusParkingSlot of(String value) {
		
		return Arrays.stream(StatusParkingSlot.values())
		          .filter(c -> value.equals(c.getValue()))
		          .findFirst()
		          .orElse(null);
	}
	

}
