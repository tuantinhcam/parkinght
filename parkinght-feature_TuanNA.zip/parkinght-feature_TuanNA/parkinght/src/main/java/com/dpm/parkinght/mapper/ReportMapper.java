package com.dpm.parkinght.mapper;

import com.dpm.parkinght.common.GetNotNull;
import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.dto.entity.Report;
import com.dpm.parkinght.dto.request.ReportCreateRequest;

import java.time.LocalDateTime;
import java.util.UUID;

public class ReportMapper {
	public static Report convertToReport(ReportCreateRequest request) {
		Report report = new Report();
		report.setReportId(UUID.randomUUID().toString());
		report.setIsRead(0);
		report.setContent(request.getContent());
		report.setVehiclePlateNumber(request.getVehiclePlateNumber());
		report.setProcessingStatus(0);
		report.setCreateDate(LocalDateTime.now());
		report.setManagerId(null);
		return report;
	}
}