package com.dpm.parkinght.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportUpdateRequest {
    private String reportId;
    private Integer processingStatus;

}
