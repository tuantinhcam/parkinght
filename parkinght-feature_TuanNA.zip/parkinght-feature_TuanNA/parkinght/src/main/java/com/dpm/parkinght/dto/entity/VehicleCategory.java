package com.dpm.parkinght.dto.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Entity
@Table(name = "tbl_vehicle_category")
public class VehicleCategory implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "vehicle_category_id", unique = true, nullable = false)
	private String vehicleCategoryId;

	@Column(name = "vehicle_category_name", length = 30)
	private String vehicleCategoryName;

	@Column(name = "update_time")
	private LocalDateTime updateTime;

	@Column(name = "del_flag")
	private Boolean delFlag;

	@Column(name = "del_date")
	private LocalDateTime delDate;

	@Column(name = "del_user_id")
	private String delUserId;

	@OneToMany(mappedBy = "vehicleCategory")
	@EqualsAndHashCode.Exclude
	@ToString.Exclude
	@JsonIgnore
	private List<Vehicle> vehicles;

	@OneToMany(mappedBy = "vehicleCategory")
	@EqualsAndHashCode.Exclude
	@ToString.Exclude
	@JsonIgnore
	private List<ParkingSlot> parkingSlot;

	
	public String getVehicleCategoryId() {
		return vehicleCategoryId;
	}

	public void setVehicleCategoryId(String vehicleCategoryId) {
		this.vehicleCategoryId = vehicleCategoryId;
	}

	public String getVehicleCategoryName() {
		return vehicleCategoryName;
	}

	public void setVehicleCategoryName(String vehicleCategoryName) {
		this.vehicleCategoryName = vehicleCategoryName;
	}

	public LocalDateTime getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(LocalDateTime updateTime) {
		this.updateTime = updateTime;
	}

	public Boolean getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(Boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDateTime getDelDate() {
		return delDate;
	}

	public void setDelDate(LocalDateTime delDate) {
		this.delDate = delDate;
	}

	public String getDelUserId() {
		return delUserId;
	}

	public void setDelUserId(String delUserId) {
		this.delUserId = delUserId;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

}