package com.dpm.parkinght.dto.entity;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import org.hibernate.annotations.UpdateTimestamp;

import com.dpm.parkinght.enums.Role;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Entity
@Table(name = "tbl_user")
@Data
public class User {
    @Id
    @Column(name = "user_id", unique = true, nullable = false, length = 50)
    private String userId;

    @Column(name = "full_name")
    private String fullName;

    @Column(name = "date_of_birth")
    private Date birthday;

    @Column(name = "phone_number", length = 10, unique = true)
    private String phoneNumber;

    @Column(name = "email", length = 50, unique = true)
    private String email;

    @Column(name = "password") //length=30
    private String password;

    @Column(name = "createdDate")
    private LocalDateTime createdDate;

    @Column(name = "update_time")
    @UpdateTimestamp
    private LocalDateTime updateTime;

    @Column(name = "del_flag")
    private Boolean delFlag;

    @Column(name = "del_date")
    private LocalDateTime delDate;

    @Column(name = "del_user_id")
    private String delUserId;

    @Column(name = "last_login")
    private LocalDateTime lastLogin;

    @OneToMany(mappedBy = "user")
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    @JsonIgnore
    private List<Vehicle> vehicles;

//    @OneToOne
    @Column(name = "role", nullable = false)
    private Role role;

    

}