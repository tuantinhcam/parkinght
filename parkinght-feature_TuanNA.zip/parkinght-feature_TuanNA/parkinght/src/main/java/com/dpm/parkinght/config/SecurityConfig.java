package com.dpm.parkinght.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import com.dpm.parkinght.filter.JwtAuthFilter;
import com.dpm.parkinght.repository.UserRepository;
import com.dpm.parkinght.service.impl.UserInfoServiceImpl;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
	// @Autowired
	private final JwtAuthFilter authFilter;

	private final UserRepository userRepository;
	private final PasswordEncoder encoder;

	@Autowired
	@Lazy
	public SecurityConfig(JwtAuthFilter authFilter, UserRepository userRepository, PasswordEncoder encoder) {
		this.authFilter = authFilter;
		this.userRepository = userRepository;
		this.encoder = encoder;
	}

	// User Creation
	@Bean
	public UserDetailsService userDetailsService() {
		return new UserInfoServiceImpl(userRepository, encoder);
	}

	// Configuring HttpSecurity
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http.exceptionHandling().authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED));
		return http.csrf().disable().authorizeHttpRequests()
				.requestMatchers("/user/create", "/auth/addNewUser", "/auth/**", "/reset/**", "/checkQR/**").permitAll().and().logout().permitAll().and()
				.authorizeHttpRequests().requestMatchers("/vehicle-category/**").authenticated().and()
				.authorizeHttpRequests().requestMatchers("/parking-slot/**").authenticated().and()
				.authorizeHttpRequests().requestMatchers("/api/**").authenticated().and()
				.authorizeHttpRequests().requestMatchers("/vehicle/**").authenticated().and().authorizeHttpRequests()
				.requestMatchers("/booking/**").authenticated().and().authorizeHttpRequests()
				.requestMatchers("/report/**").authenticated().and().authorizeHttpRequests()
				.requestMatchers("/feedback/**").authenticated().and().authorizeHttpRequests()
				.requestMatchers("/user/**").authenticated().and().authorizeHttpRequests()
				.requestMatchers("/auth/admin/**").authenticated().and().sessionManagement()	     
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
				.authenticationProvider(authenticationProvider())
				.addFilterBefore(authFilter, UsernamePasswordAuthenticationFilter.class).build();
	}

	// Password Encoding
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public AuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
		authenticationProvider.setUserDetailsService(userDetailsService());
		authenticationProvider.setPasswordEncoder(passwordEncoder());
		return authenticationProvider;
	}

	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
		return config.getAuthenticationManager();
	}

	@Bean
	public FilterRegistrationBean<CorsFilter> corsConfigurationSource() {
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOrigins(Arrays.asList("http://localhost:3000", "https://parking-ht-fe-web.vercel.app"));
		configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE"));
//        configuration.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type", ""));
		configuration.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type"));
		configuration.setAllowCredentials(true);
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);

		FilterRegistrationBean<CorsFilter> bean = new FilterRegistrationBean<>(new CorsFilter(source));
		bean.setOrder(Ordered.HIGHEST_PRECEDENCE);

		return bean;
	}

}