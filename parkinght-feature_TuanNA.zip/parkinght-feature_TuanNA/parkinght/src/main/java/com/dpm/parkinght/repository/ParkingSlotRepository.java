package com.dpm.parkinght.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.dpm.parkinght.dto.entity.ParkingSlot;
import com.dpm.parkinght.dto.response.VehicleCategoryResponse;

public interface ParkingSlotRepository extends JpaRepository<ParkingSlot, String> {

	@Query(value = "SELECT tbl_parking_slot.parking_slot_id FROM tbl_parking_slot JOIN tbl_booking ON "
			+ "tbl_parking_slot.parking_slot_id = tbl_booking.parking_slot_id "
			+ "WHERE tbl_booking.create_Date not BETWEEN :startDate AND :endDate", nativeQuery = true)
	public List<String> checkAvailableSlot(@Param("startDate") LocalDateTime startDate,
			@Param("endDate") LocalDateTime endDate);

	@Query(value = "SELECT * FROM tbl_parking_slot " + " WHERE tbl_parking_slot.parking_slot_id IN "
			+ "(SELECT tbl_booking.parking_slot_id FROM tbl_booking where tbl_booking.booking_id = :bookingID)", nativeQuery = true)
	public ParkingSlot findSlotByBookingId(@Param("bookingID") String bookingID);

	List<ParkingSlot> findAllByDelFlag(boolean delFlag);

	ParkingSlot findByAreaAndAndName(String area, String name);

	List<ParkingSlot> findByArea(String area);

	@Query(value = "SELECT DISTINCT tbl_booking.parking_slot_id FROM parkinght.tbl_booking\r\n"
			+ "WHERE tbl_booking.end_date < now()", nativeQuery = true)
	List<String> getExpiredSlot();

	@Modifying
	@Transactional
	@Query(value = "UPDATE tbl_parking_slot\r\n" + "SET tbl_parking_slot.parking_slot_status = 1\r\n"
			+ "WHERE tbl_parking_slot.parking_slot_id IN :parkingSlotIds", nativeQuery = true)
	int updateStatusSlot(@Param("parkingSlotIds") List<String> parkingSlotIds);

	@Query(value = "select tps.parking_slot_area  from tbl_parking_slot tps WHERE tps.del_flag=false and 1=1 group by tps.parking_slot_area", nativeQuery = true)
	List<String> findAllArea();

	@Query(value = "select new com.dpm.parkinght.dto.response.VehicleCategoryResponse(tps.area) from ParkingSlot tps  where  tps.vehicleCategory.vehicleCategoryId =?1 group by tps.area")
	List<VehicleCategoryResponse> findAreaByVehicleCategory(String categoryId);

	@Query(value = "select new com.dpm.parkinght.dto.response.VehicleCategoryResponse(tps.area) from ParkingSlot tps  where  tps.vehicleCategory.vehicleCategoryId =?1 and tps.delFlag =?2 group by tps.area")
	List<VehicleCategoryResponse> findAreaByVehicleCategoryAndDelFlag(String categoryId, boolean delFlag);
}
