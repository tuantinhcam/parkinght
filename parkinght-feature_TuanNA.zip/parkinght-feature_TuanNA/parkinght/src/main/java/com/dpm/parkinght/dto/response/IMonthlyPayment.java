package com.dpm.parkinght.dto.response;

public interface IMonthlyPayment {
	Integer getmonthInYear();
	Long getAmountInMonth();
}
