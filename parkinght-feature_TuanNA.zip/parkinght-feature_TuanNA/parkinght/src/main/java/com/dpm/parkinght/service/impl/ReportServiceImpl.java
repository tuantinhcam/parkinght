package com.dpm.parkinght.service.impl;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.dto.entity.Feedback;
import com.dpm.parkinght.dto.entity.Report;
import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.entity.Vehicle;
import com.dpm.parkinght.dto.request.ReportCreateRequest;
import com.dpm.parkinght.dto.request.ReportUpdateRequest;
import com.dpm.parkinght.mapper.ReportMapper;
import com.dpm.parkinght.repository.FeedbackRepository;
import com.dpm.parkinght.repository.ReportRepository;
import com.dpm.parkinght.repository.UserRepository;
import com.dpm.parkinght.repository.VehicleRepository;
import com.dpm.parkinght.service.ReportService;
import com.dpm.parkinght.service.UserService;

@Service
public class ReportServiceImpl implements ReportService {
	private final ReportRepository reportRepository;
	private final UserService userService;
	private final UserRepository userRepository;
	private final VehicleRepository vehicleRepository;
	private final FeedbackRepository feedbackRepository;

	@Autowired
	public ReportServiceImpl(ReportRepository reportRepository, UserService userService, UserRepository userRepository,
			VehicleRepository vehicleRepository, FeedbackRepository feedbackRepository) {
		this.reportRepository = reportRepository;
		this.userService = userService;
		this.userRepository = userRepository;
		this.vehicleRepository = vehicleRepository;
		this.feedbackRepository = feedbackRepository;
	}

	@Override
	public List<Report> getAll(Principal principal) {
		if (!userService.isDriver(principal.getName())) {
			return reportRepository.findAll();
		} else {
			User user = userService.findByPhone(principal.getName());
			return reportRepository.findAllByUserId(user.getUserId());
		}
	}

	@Override
	public Report findById(String id) {
		return reportRepository.findById(id).orElseThrow(() -> new LogicException("Not found report with id: " + id));
	}

	@Override
	public List<Report> getReportByDriver(Principal principal) {
		if (!userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		User user = userService.findByPhone(principal.getName());
		return reportRepository.findAllByUserId(user.getUserId());
	}

	@Override
	public Report save(ReportCreateRequest request, Principal principal) {
		if (!userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		User user = userService.findByPhone(principal.getName());
		Report report = ReportMapper.convertToReport(request);
		report.setUserId(user.getUserId());
		
		return reportRepository.save(report);
	}

	@Override
	public Report update(Principal principal, ReportUpdateRequest reportUpdateRequest) {
		if (userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		User user = userService.findByPhone(principal.getName());
		Report report = reportRepository.findById(reportUpdateRequest.getReportId()).orElseThrow(
				() -> new LogicException("Not found report with id: " + reportUpdateRequest.getReportId()));
		report.setProcessingStatus(reportUpdateRequest.getProcessingStatus());
		report.setIsRead(1);
		report.setProcessingDate(LocalDateTime.now());
		report.setManagerId(user.getUserId());

		return reportRepository.save(report);
	}

	@Override
	public List<Report> getUnreadReport(Principal principal, Integer isRead) {
		if (userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		return reportRepository.findAllByIsRead(isRead); // 0 la chua doc, 1 la doc roi
	}

	@Override
	public Integer countUnreadReport(Principal principal, Integer isReadStatus) {
		return getUnreadReport(principal, isReadStatus).size();
	}

}
