package com.dpm.parkinght.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.dpm.parkinght.dto.entity.Payment;
import com.dpm.parkinght.dto.response.IMonthlyPayment;
import com.dpm.parkinght.repository.PaymentRepository;
import com.dpm.parkinght.service.PaymentService;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	PaymentRepository paymentRepository;


	@Override
	public Payment insertPayment(Payment payment) {
		return paymentRepository.save(payment);
	}

	@Override
	@Scheduled(cron = "0 0 * ? * *") //chay method tinh tong trong ngay sau moi~ gio
	public Long totalPaymentInDay() {
		long sumDay = 0;
		sumDay += (paymentRepository.totalPaymentInDay()/100);
		System.out.println(sumDay);
		return sumDay;
	}
	
	@Override
	public List<IMonthlyPayment> totalPaymentInMonth() {
		List<IMonthlyPayment> monthlyList = paymentRepository.totalPaymentInMonth();
		return monthlyList;
	}
	

}
