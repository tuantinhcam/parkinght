package com.dpm.parkinght.dto.response;

import java.time.LocalDateTime;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserResponse {
    private String userId;
    private String fullName;
    private Date birthday;
    private String phoneNumber;
    private String email;
    private String password;
    private LocalDateTime createdDate;
    private LocalDateTime updateTime;
    private Boolean delFlag;
    private LocalDateTime delDate;
    private String delUserId;
    private LocalDateTime lastLogin;


}
