package com.dpm.parkinght.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.dpm.parkinght.dto.entity.Payment;
import com.dpm.parkinght.dto.response.IMonthlyPayment;

public interface PaymentRepository extends JpaRepository<Payment, String>{

	@Query(value = "SELECT COALESCE(SUM(tbl_payment.amount_paid),0) FROM tbl_payment\r\n"
			+ "WHERE tbl_payment.payment_status = 1\r\n"
			+ "AND DATE(tbl_payment.create_time) = DATE(NOW())",nativeQuery = true)
	Long totalPaymentInDay ();
	
	
	@Query(value = "SELECT \r\n"
			+ "    MONTH(tbl_payment.create_time) AS monthInYear,\r\n"
			+ "    SUM(amount_paid) AS amountInMonth\r\n"
			+ "FROM \r\n"
			+ "    tbl_payment\r\n"
			+ "WHERE tbl_payment.payment_status = 1\r\n"
			+ "GROUP BY \r\n"
			+ "    MONTH(tbl_payment.create_time)\r\n"
			+ "ORDER BY monthInYear; ", nativeQuery = true)
	List<IMonthlyPayment> totalPaymentInMonth();
	
}
