package com.dpm.parkinght.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.dpm.parkinght.dto.entity.Feedback;
import com.dpm.parkinght.dto.entity.Report;

public interface FeedbackRepository extends JpaRepository<Feedback, String> {
	List<Feedback> findAllByIsRead(Integer isRead);

	List<Feedback> findAllByReport(Report report);

	@Query(value = "select fb from Feedback  fb inner join Report rp on fb.report.reportId=rp.reportId where rp.userId=?1 and fb.report.reportId=?2")
	List<Feedback> findAllByReportAndDriver(String userId, String reportId);
}
