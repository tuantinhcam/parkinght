package com.dpm.parkinght.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dpm.parkinght.common.BaseResponse;
import com.dpm.parkinght.dto.entity.VehicleCategory;
import com.dpm.parkinght.dto.request.VehicleCategoryCreateRequest;
import com.dpm.parkinght.service.VehicleCategoryService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/vehicle-category")
//@RequiredArgsConstructor
public class VehicleCategoryController {
//	@Autowired
    private final VehicleCategoryService vehicleCategoryService;

    @Autowired
    public VehicleCategoryController(VehicleCategoryService vehicleCategoryService) {
        this.vehicleCategoryService = vehicleCategoryService;
    }

    @GetMapping("/get-all")
    public BaseResponse<List<VehicleCategory>> getAll(Principal principal) {
        return BaseResponse.ok(vehicleCategoryService.getAll(principal));
    }

    @PostMapping("/create")
    public BaseResponse<?> createVehicleCategory(@Valid @RequestBody VehicleCategoryCreateRequest request, Principal principal) {
        return BaseResponse.ok(vehicleCategoryService.save(request,principal));
    }

    @GetMapping("/get-by-id/{id}")
    public BaseResponse<?> getById(Principal principal,@PathVariable("id") String id) {
        return BaseResponse.ok(vehicleCategoryService.findById(principal,id));
    }

    @PutMapping("/delete/{id}")
    public BaseResponse<?> delete(@PathVariable("id") String id, Principal principal) {
        return BaseResponse.ok(vehicleCategoryService.deleteVehicleCategory(id, principal));
    }

    @PutMapping("/update")
    public BaseResponse<?> update(@Valid @RequestBody VehicleCategory category, Principal principal) {
        return BaseResponse.ok(vehicleCategoryService.update(category, principal));
    }
}
