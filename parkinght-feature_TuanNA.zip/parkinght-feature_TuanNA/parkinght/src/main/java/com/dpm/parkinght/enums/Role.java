package com.dpm.parkinght.enums;

import java.util.Arrays;

import org.springframework.security.core.GrantedAuthority;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum Role implements GrantedAuthority {

	ADMIN("0", "ADMIN"), MANAGER("1", "MANAGER"), DRIVER("2", "DRIVER");

	private String value;
	private String display;

	public String getValue() {
		return value;
	}

	public String getDisplay() {
		return display;
	}
	
	public static Role of(String value) {
		
		return Arrays.stream(Role.values())
		          .filter(c -> value.equals(c.getValue()))
		          .findFirst()
		          .orElse(null);
	}

	@Override
	public String getAuthority() {
		// TODO Auto-generated method stub
		return display;
	}
	

}
