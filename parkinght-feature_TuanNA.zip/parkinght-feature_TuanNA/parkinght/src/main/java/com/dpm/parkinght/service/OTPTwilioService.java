package com.dpm.parkinght.service;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.config.TwilioConfig;
import com.dpm.parkinght.dto.request.OTPSendRequest;
import com.dpm.parkinght.dto.response.OTPResponse;
import com.dpm.parkinght.enums.StatusOTP;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

@Service
public class OTPTwilioService {

	@Autowired
	private TwilioConfig twilioconfig;

	private static final Integer EXPIRE_MINS = 2;

	public static LoadingCache<String, Integer> otpMap;

	public OTPTwilioService() {
		super();
		otpMap = CacheBuilder.newBuilder().expireAfterWrite(EXPIRE_MINS, TimeUnit.MINUTES)
				.build(new CacheLoader<String, Integer>() {
					public Integer load(String key) {
						return 0;
					}
				});
	}

	public OTPResponse sendOTPPassword(OTPSendRequest otpRequest) {

		OTPResponse otpResponse = null;		
		String convertedPhone = convertVNPhoneNum(otpRequest.getDestPhoneNumber());
		try {
			PhoneNumber to = new PhoneNumber(convertedPhone);
			PhoneNumber from = new PhoneNumber(twilioconfig.getPhoneNumber());
			int otp = generateOTP(otpRequest.getDestPhoneNumber());
			String otpMessage = "Ma so OTP cua ban la " + otp
					+ ". Tuyet doi khong chia se cho bat cu ai. ParkingHT with luv";

			Message message = Message.creator(to, from, otpMessage).create();
			otpResponse = new OTPResponse(StatusOTP.DELIVERED, "200", otpMessage);
		} catch (Exception e) {
			otpResponse = new OTPResponse(StatusOTP.FAILED, "401", e.getMessage());
		}
		return otpResponse;

	}

	public int validateOTP(String phoneNumber) throws LogicException {
		try {
			return otpMap.get(phoneNumber);
		} catch (Exception e) {
			throw new LogicException("OTP khong hop le hoa da het han");
		}
	}

	// This method is used to clear the OTP catched already
	public void clearOTP(String key) {
		otpMap.invalidate(key);
	}

	// generate random otp
	private int generateOTP(String key) {
		Random random = new Random();
		int otp = 000000 + random.nextInt(999999);
		otpMap.put(key, otp);
		return otp;
	}

	private String convertVNPhoneNum(String phoneNumber) {
		StringBuilder sb = new StringBuilder(phoneNumber);
		String convertedPhone = sb.replace(0, 1, "+84").toString();
		return convertedPhone;

	}

}
