package com.dpm.parkinght.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OTPSendRequest {
	@NotBlank(message = "So dien thoai khong duoc de trong")
	private String destPhoneNumber;
}
