package com.dpm.parkinght.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.dpm.parkinght.dto.entity.User;

import jakarta.validation.constraints.NotBlank;

public interface UserRepository extends JpaRepository<User, String> {
	
	Optional<User> findByPhoneNumber(@NotBlank String phoneNumber);

	User findByEmail(@NotBlank String email);
	
	@Query(value = "SELECT COUNT(user_id) FROM tbl_user\r\n"
			+ "WHERE DATE(created_date) = CURDATE()", nativeQuery = true)
	int getTotalRegisterInDay();
	
}
