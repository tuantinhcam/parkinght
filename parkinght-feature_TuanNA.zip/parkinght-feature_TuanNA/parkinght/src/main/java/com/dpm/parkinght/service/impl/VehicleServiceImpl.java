package com.dpm.parkinght.service.impl;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpm.parkinght.common.GetNotNull;
import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.entity.Vehicle;
import com.dpm.parkinght.dto.entity.VehicleCategory;
import com.dpm.parkinght.dto.request.VehicleCreateRequest;
import com.dpm.parkinght.dto.request.VehicleUpdateRequest;
import com.dpm.parkinght.mapper.VehicleMapper;
import com.dpm.parkinght.repository.UserRepository;
import com.dpm.parkinght.repository.VehicleCategoryRepository;
import com.dpm.parkinght.repository.VehicleRepository;
import com.dpm.parkinght.service.UserService;
import com.dpm.parkinght.service.VehicleService;

@Service
//@RequiredArgsConstructor
public class VehicleServiceImpl implements VehicleService {
	// @Autowired
	private final VehicleRepository vehicleRepository;
	// @Autowired
	private final UserRepository userRepository;
	// @Autowired
	private final VehicleCategoryRepository vehicleCategoryRepository;
	private final UserService userService;

	@Autowired
	public VehicleServiceImpl(VehicleRepository vehicleRepository, UserRepository userRepository,
			VehicleCategoryRepository vehicleCategoryRepository, UserService userService) {
		this.vehicleRepository = vehicleRepository;
		this.userRepository = userRepository;
		this.vehicleCategoryRepository = vehicleCategoryRepository;
		this.userService = userService;
	}

	@Override
	public List<Vehicle> getAll(Principal principal) {
		if (userService.isDriver(principal.getName())) {
			// driver view ban ghi chua xoa
			User user = userService.findByPhone(principal.getName());
			return vehicleRepository.findAllByUserAndDelFlag(user, false);
		} else {
			// admin+manager view all
			return vehicleRepository.findAll();
		}

	}

	@Override
	public Vehicle save(VehicleCreateRequest request, Principal principal) {
		if (!userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		if (GetNotNull.isNull(request.getVehicleName()) || GetNotNull.isNull(request.getPlateNumber())) {
			throw new LogicException("Insert fail!");
		}
		Vehicle vehicle = VehicleMapper.convertToVehicle(request);
		Vehicle checkByPlateNumber = vehicleRepository.findByPlateNumber(request.getPlateNumber());
		if (checkByPlateNumber != null) {
			throw new LogicException("Bien so xe da ton tai");
		}
		User user = userService.findByPhone(principal.getName());
		VehicleCategory vehicleCategory = vehicleCategoryRepository.findById(request.getCategoryId())
				.orElseThrow(() -> new LogicException("Vehicle Category not found"));
		vehicle.setUser(user);
		vehicle.setVehicleCategory(vehicleCategory);
		return vehicleRepository.save(vehicle);
	}

	@Override
	public Vehicle findById(Principal principal, String id) {
		Vehicle vehicle = vehicleRepository.findById(id)
				.orElseThrow(() -> new LogicException("Not found vehicle with id: " + id));
		if (userService.isDriver(principal.getName())) {
			if (vehicle.getDelFlag()) {
				throw new LogicException("Not found vehicle  with id: " + id);
			}
		}
		return vehicle;

	}

	@Override
	public Vehicle deleteVehicle(Principal principal, String id) {
		if (!userService.isAdmin(principal.getName())) {
			throw new LogicException("Not permission");
		}
		Vehicle vehicle = findById(principal, id);
		vehicle.setUpdateTime(LocalDateTime.now());
		vehicle.setDelFlag(true);
		vehicle.setDelDate(LocalDateTime.now());
		Optional<User> user = userRepository.findByPhoneNumber(principal.getName());
		vehicle.setDelUserId(user.get().getUserId());
		return vehicleRepository.save(vehicle);
	}

	@Override
	public Vehicle update(VehicleUpdateRequest request, Principal principal) {
		if (!userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		User user = userService.findByPhone(principal.getName());
		if (request.getPlateNumber().length() > 15 || request.getPlateNumber().length() < 8) {
			throw new LogicException("Biển số xe lớn hơn 8 và nhỏ hơn hoặc bằng 15 ký tự");
		}
		Vehicle vehicle = findById(principal, request.getVehicleId());
		BeanUtils.copyProperties(request, vehicle, GetNotNull.getNullPropertyNames(request));
		if (!user.getUserId().equals(vehicle.getUser().getUserId())) {
			throw new LogicException("Not permission!");
		}
		VehicleCategory vehicleCategory = vehicleCategoryRepository.findById(request.getCategoryId())
				.orElseThrow(() -> new LogicException("Vehicle Category not found"));
		vehicle.setUser(user);
		vehicle.setVehicleCategory(vehicleCategory);
		vehicle.setUpdateTime(LocalDateTime.now());
		return vehicleRepository.save(vehicle);
	}

	@Override
	public List<Vehicle> getByVehicleCategory(Principal principal, String categoryId) {
		if (!userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		if (GetNotNull.isNull(categoryId)) {
			throw new LogicException("Not found vehicle category with id: " + categoryId);
		}
		VehicleCategory category = vehicleCategoryRepository.findById(categoryId)
				.orElseThrow(() -> new LogicException("Not found vehicle category with id: " + categoryId));
		return vehicleRepository.findAllByVehicleCategory(category);
	}
}
