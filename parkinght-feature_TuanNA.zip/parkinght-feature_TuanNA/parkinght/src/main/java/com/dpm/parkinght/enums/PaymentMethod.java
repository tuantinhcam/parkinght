package com.dpm.parkinght.enums;

public enum PaymentMethod {
    MOMO,
    VNPAY,
    ZALOPAY,
}
