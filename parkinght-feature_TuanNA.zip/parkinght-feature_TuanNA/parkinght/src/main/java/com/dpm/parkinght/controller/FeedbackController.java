package com.dpm.parkinght.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dpm.parkinght.common.BaseResponse;
import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.dto.entity.Feedback;
import com.dpm.parkinght.dto.request.FeedbackRequest;
import com.dpm.parkinght.service.FeedbackService;

@RestController
@RequestMapping("/feedback")
public class FeedbackController {
	private final FeedbackService feedBackService;

	public FeedbackController(FeedbackService feedBackService) {
		this.feedBackService = feedBackService;
	}

	@GetMapping("/get-all")
	public BaseResponse<List<Feedback>> getAll(Principal principal) {
		return BaseResponse.ok(feedBackService.getAll(principal));
	}

	@GetMapping("/get-unread/{id}")
	public BaseResponse<?> getUnreadFeedback(Principal principal, @PathVariable("id") Integer isRead) {
		Integer isReadStatus = 0;
		try {
			isReadStatus = Integer.parseInt(isRead.toString());

		} catch (Exception e) {
			throw new LogicException("Vui long nhap trang thai da xem feedback hoac chua xem feedback");
		}
		return BaseResponse.ok(feedBackService.getUnreadReport(principal, isReadStatus));
	}

	@GetMapping("/get-count-unread/{id}")
	public BaseResponse<?> getCountUnreadFeedback(Principal principal, @PathVariable("id") Integer isRead) {
		Integer isReadStatus = 0;
		try {
			isReadStatus = Integer.parseInt(isRead.toString());

		} catch (Exception e) {
			throw new LogicException("Vui long nhap trang thai da xem report hoac chua xem report");
		}
		return BaseResponse.ok(feedBackService.countUnreadReport(principal, isReadStatus));
	}

	@PostMapping("/create/{id}")
	public BaseResponse<?> createFeedback(@PathVariable("id") String reportId, Principal principal) {
		return BaseResponse.ok(feedBackService.save(reportId, principal));
	}

	@GetMapping("/get-by-id/{id}")
	public BaseResponse<?> getById(Principal principal, @PathVariable("id") String id) {
		return BaseResponse.ok(feedBackService.findById(principal, id));
	}

	@PutMapping("/update/{id}")
	public BaseResponse<?> update(@PathVariable("id") String id, @RequestBody FeedbackRequest request,
			Principal principal) {
		return BaseResponse.ok(feedBackService.update(id, request, principal));
	}

	@GetMapping("/get-by-report/{id}")
	public BaseResponse<?> getByReportId(Principal principal, @PathVariable("id") String id) {
		return BaseResponse.ok(feedBackService.findByReport(principal, id));
	}
}