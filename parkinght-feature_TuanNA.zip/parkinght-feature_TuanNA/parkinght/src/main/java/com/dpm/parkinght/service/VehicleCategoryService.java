package com.dpm.parkinght.service;

import com.dpm.parkinght.dto.entity.VehicleCategory;
import com.dpm.parkinght.dto.request.VehicleCategoryCreateRequest;

import java.security.Principal;
import java.util.List;

public interface VehicleCategoryService {
	List<VehicleCategory> getAll(Principal principal);

	VehicleCategory save(VehicleCategoryCreateRequest vehicleCategory, Principal principal);

	VehicleCategory findById(Principal principal, String id);

	VehicleCategory deleteVehicleCategory(String id, Principal principal);

	VehicleCategory update(VehicleCategory vehicleCategory, Principal principal);

	VehicleCategory findByName(String name);
}
