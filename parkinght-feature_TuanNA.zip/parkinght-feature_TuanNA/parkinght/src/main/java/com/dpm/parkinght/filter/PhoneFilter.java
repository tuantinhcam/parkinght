package com.dpm.parkinght.filter;

public class PhoneFilter {
    public static boolean isValidPhoneNumber(String phoneNumber) {
        if (phoneNumber == null) {
            return false;
        } else {
            return phoneNumber.length() == 10 && (phoneNumber.startsWith("09") || phoneNumber.startsWith("08") || phoneNumber.startsWith("07") || phoneNumber.startsWith("05") || phoneNumber.startsWith("03"));
        }
    }
}
