package com.dpm.parkinght.mapper;

import java.util.UUID;

import com.dpm.parkinght.dto.entity.Booking;
import com.dpm.parkinght.dto.entity.Payment;
import com.dpm.parkinght.enums.PaymentMethod;
import com.dpm.parkinght.enums.StatusPayment;

public class PaymentCreator {

	public Payment createPayment(Booking booking, long amount,String transactionID) {
		Payment payment = new Payment();
		payment.setPayment_Id(UUID.randomUUID().toString());
		payment.setBooking(booking);
		payment.setStatus(StatusPayment.PAID);
		payment.setTransaction_Id(transactionID);
		payment.setTotal_Price(amount);
		payment.setPayment_Method(PaymentMethod.VNPAY);
		return payment;
	}
}
