package com.dpm.parkinght.dto.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "tbl_vehicle")
@Data
public class Vehicle {
    @Id
    @Column(name = "vehicle_id", unique = true, nullable = false)
    private String vehicleId;

    @Column(name = "vehicle_plate_number", length = 15, unique = true)
    private String plateNumber;

    @Column(name = "vehicle_name", length = 100)
    private String vehicleName;

    @Column(name = "vehicle_number_of_fouls")
    private Integer numberOfFouls;

    @Column(name = "update_time")
    private LocalDateTime updateTime;

    @Column(name = "del_flag")
    private Boolean delFlag;

    @Column(name = "del_date")
    private LocalDateTime delDate;

    @Column(name = "del_user_id")
    private String delUserId;

    @ManyToOne
    @JoinColumn(name = "vehicle_category_id")
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private VehicleCategory vehicleCategory;

    @ManyToOne
    @JoinColumn(name = "user_id")
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private User user;

//    @OneToMany(mappedBy = "vehicle")
//    @EqualsAndHashCode.Exclude
//    @ToString.Exclude
//	@JsonIgnore
//    private List<Report> report;

	@OneToMany(mappedBy = "vehicle")
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
	@JsonIgnore
    private List<Booking> booking;

	public Vehicle() {
	}

	public Vehicle(String vehicleId, String plateNumber, String vehicleName, Integer numberOfFouls, LocalDateTime updateTime, Boolean delFlag, LocalDateTime delDate,
			String delUserId, VehicleCategory vehicleCategory, User user
			/*, List<Report> report*/) {
		this.vehicleId = vehicleId;
		this.plateNumber = plateNumber;
		this.vehicleName = vehicleName;
		this.numberOfFouls = numberOfFouls;
		this.updateTime = updateTime;
		this.delFlag = delFlag;
		this.delDate = delDate;
		this.delUserId = delUserId;
		this.vehicleCategory = vehicleCategory;
		this.user = user;
//		this.report = report;
	}

	public Vehicle(String vehicleId, String plateNumber, String vehicleName, Integer numberOfFouls, LocalDateTime updateTime, Boolean delFlag, LocalDateTime delDate, String delUserId, 
			VehicleCategory vehicleCategory, User user,
			//List<Report> report,
			List<Booking> booking) {
		this.vehicleId = vehicleId;
		this.plateNumber = plateNumber;
		this.vehicleName = vehicleName;
		this.numberOfFouls = numberOfFouls;
		this.updateTime = updateTime;
		this.delFlag = delFlag;
		this.delDate = delDate;
		this.delUserId = delUserId;
		this.vehicleCategory = vehicleCategory;
		this.user = user;
		//this.report = report;
		this.booking = booking;
	}

	public List<Booking> getBooking() {
		return booking;
	}

	public void setBooking(List<Booking> booking) {
		this.booking = booking;
	}

	public String getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getPlateNumber() {
		return plateNumber;
	}

	public void setPlateNumber(String plateNumber) {
		this.plateNumber = plateNumber;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public Integer getNumberOfFouls() {
		return numberOfFouls;
	}

	public void setNumberOfFouls(Integer numberOfFouls) {
		this.numberOfFouls = numberOfFouls;
	}

	public LocalDateTime getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(LocalDateTime updateTime) {
		this.updateTime = updateTime;
	}

	public Boolean getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(Boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDateTime getDelDate() {
		return delDate;
	}

	public void setDelDate(LocalDateTime delDate) {
		this.delDate = delDate;
	}

	public String getDelUserId() {
		return delUserId;
	}

	public void setDelUserId(String delUserId) {
		this.delUserId = delUserId;
	}

	public VehicleCategory getVehicleCategory() {
		return vehicleCategory;
	}

	public void setVehicleCategory(VehicleCategory vehicleCategory) {
		this.vehicleCategory = vehicleCategory;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

//	public List<Report> getReport() {
//		return report;
//	}
//
//	public void setReport(List<Report> report) {
//		this.report = report;
//	}
    
}