package com.dpm.parkinght.common.handler;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.dpm.parkinght.common.BaseResponse;
import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.common.errors.UnauthorizedException;

@ControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    /**
     * Tất cả các Exception không được khai báo sẽ được xử lý tại đây
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleAllException(Exception ex, WebRequest request) {
        ex.printStackTrace();
        logger.error(ex.getMessage());
        return buildResponseEntity(BaseResponse.error(ex.getLocalizedMessage(), HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
    }
        /**
     * Description: Handle record not found exception
     *
     * @param request
     * @param ex
     * @return
     */
    @ExceptionHandler({LogicException.class})
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public final ResponseEntity<Object> handleRecordNotFoundException(LogicException ex, WebRequest request) {
        ex.printStackTrace();
        logger.error(ex.getMessage());
        String message = ex.getLocalizedMessage();
        return buildResponseEntity(BaseResponse.error("error", HttpStatus.BAD_REQUEST.value(), message), HttpStatus.BAD_REQUEST);
    }

    /**
     * Description: Handle authentication exception
     *
     * @param request
     * @param ex
     * @return
     */
    @ExceptionHandler({UnauthorizedException.class}) //, AuthenticationException.class
    @ResponseStatus(value = HttpStatus.UNAUTHORIZED)
    public final ResponseEntity<Object> handleAuthenticationException(Exception ex, WebRequest request) {
        ex.printStackTrace();
        logger.error(ex.getMessage());
        String message = ex.getLocalizedMessage();
        if (!message.equals("USER_NOT_FOUND_ERROR")) {
            message = "USER_USERNAME_PASSWORD_ERROR";
        }
        BaseResponse<Object> baseResponse = BaseResponse.error(message, HttpStatus.UNAUTHORIZED.value());
        baseResponse.setData("USER_USERNAME_PASSWORD_ERROR"); // Đặt giá trị dữ liệu mong muốn
        return buildResponseEntity(baseResponse, HttpStatus.UNAUTHORIZED);
    }

    /**
     * Description: build return response entity
     *
     * @param baseResponse
     * @param status
     * @return
     */
    private ResponseEntity<Object> buildResponseEntity(BaseResponse<Object> baseResponse, HttpStatus status) {
        return new ResponseEntity<>(baseResponse, status);
    }

}