package com.dpm.parkinght.service;

import com.dpm.parkinght.dto.entity.Vehicle;
import com.dpm.parkinght.dto.request.VehicleCreateRequest;
import com.dpm.parkinght.dto.request.VehicleUpdateRequest;

import java.security.Principal;
import java.util.List;

public interface VehicleService {
	List<Vehicle> getAll(Principal principal);

	Vehicle save(VehicleCreateRequest request, Principal principal);

	Vehicle findById(Principal principal, String id);

	Vehicle deleteVehicle(Principal principal, String id);

	Vehicle update(VehicleUpdateRequest vehicleCategory, Principal principal);

	List<Vehicle> getByVehicleCategory(Principal principal, String categoryId);
	

}