package com.dpm.parkinght.controller;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dpm.parkinght.common.BaseResponse;
import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.common.errors.UserNotFoundException;
import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.request.OTPSendRequest;
import com.dpm.parkinght.dto.request.PasswordResetRequest;
import com.dpm.parkinght.dto.request.ValidateOTPRequest;
import com.dpm.parkinght.dto.response.OTPResponse;
import com.dpm.parkinght.enums.StatusOTP;
import com.dpm.parkinght.service.OTPTwilioService;
import com.dpm.parkinght.service.UserService;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/reset")
public class SMSController {

	@Autowired
	private OTPTwilioService twService;

	@Autowired
	private UserService userService;

	@Autowired
	private SimpMessagingTemplate webSocket;

	private final String TOPIC_DESTINATION = "lesson/sms";

	@PostMapping(value = "/send-otp", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OTPResponse> sendOTPSms(@RequestBody OTPSendRequest otpRequest, HttpSession session) {
		User user = userService.findByPhone(otpRequest.getDestPhoneNumber());
		if (otpRequest.getDestPhoneNumber().isBlank()) {
			throw new LogicException("So dien thoai khong hop le!");
		} else if (user == null) {
			throw new UserNotFoundException("Co loi da xay ra");
		}
		OTPResponse res = twService.sendOTPPassword(otpRequest);
		if (StatusOTP.DELIVERED.equals(res.getStatus())) {
			session.setAttribute("phoneNumber", otpRequest.getDestPhoneNumber());
			webSocket.convertAndSend(TOPIC_DESTINATION, LocalDateTime.now() + ": SMS da duoc gui");
			return new ResponseEntity<OTPResponse>(res, HttpStatus.OK);
		} else {
			res.setCode("401");
			res.setMessage("Loi khi gui otp");
			return new ResponseEntity<OTPResponse>(res, HttpStatus.BAD_REQUEST);
		}

	}

	@PostMapping(value = "/validateOtp")
	public BaseResponse<?> validateOtp(@RequestBody ValidateOTPRequest otpRequest, HttpSession session)
			throws LogicException {

		String url = "http://localhost:8080/parkinght/reset";
		final String FAIL = "Otp khong hop le. Vui long thu lai!";
		int otpNum = Integer.parseInt(otpRequest.getOtp());
		String phoneNumber = session.getAttribute("phoneNumber").toString();

		if (otpNum >= 0) {
			int serverOtp = twService.validateOTP(phoneNumber);

			if (serverOtp > 0) {
				if (otpNum == serverOtp) {
					twService.clearOTP(phoneNumber);
					session.setAttribute("phoneNumberPass", phoneNumber);
					url += "/resetPassword?phoneNumber=" + phoneNumber;
					return BaseResponse.ok(url);
				} else {
					return BaseResponse.badRequest(FAIL);
				}
			} else {
				return BaseResponse.badRequest("Đã có lỗi xảy ra hoặc OTP hết hạn");

			}
		} else {
			return BaseResponse.badRequest(FAIL);

		}
	}

	@PostMapping(value = "/resetPassword")
	public BaseResponse<?> changePasswordForm(@RequestParam(name = "phoneNumber") String phoneNumber,
			@RequestBody PasswordResetRequest resetRequest, HttpSession session) {
		try {
			User user = userService.findByPhone(phoneNumber);
			String userPhone = session.getAttribute("phoneNumberPass").toString();
			if (userPhone == null) {
				return BaseResponse.badRequest("Không tìm thấy số điện thoại");
			} else if (user == null) {
				return BaseResponse.badRequest("Không tìm thấy người dùng");
			} else if (!phoneNumber.equals(userPhone)) {
				return BaseResponse.badRequest("Số điện thoại không khớp");
			}
			BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();
			boolean isPasswordMatches = bcrypt.matches(resetRequest.getConfirmPassword(), user.getPassword());
			if (isPasswordMatches) {
				return BaseResponse.badRequest("Mật khẩu mới bị trùng mật khẩu cũ");
			}
			boolean isSuccess = userService.forgotPassword(userPhone, resetRequest);
			if (isSuccess) {
				return BaseResponse.ok("Đổi mật khẩu thành công");
			}
			return BaseResponse.badRequest("Đổi mật khẩu thất bại");
		} catch (RuntimeException ex) {
			return BaseResponse.badRequest(ex.getMessage());
		}

	}
}
