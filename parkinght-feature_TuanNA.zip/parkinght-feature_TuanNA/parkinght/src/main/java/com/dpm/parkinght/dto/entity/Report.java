package com.dpm.parkinght.dto.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import jakarta.persistence.*;


import java.time.LocalDateTime;


@Entity
@Table(name = "tbl_report")
@Data
public class Report {
    @Id
    @Column(name = "report_id", unique = true, nullable = false, length = 50)
    private String reportId;

    @Column(name = "content", nullable = false, columnDefinition = "text")
    private String content;

    @Column(name = "vehicle_plate_number", length = 15)
    private String vehiclePlateNumber;

    @Column(name = "createDate")
    private LocalDateTime createDate;

    @Column(name = "processingDate")
    private LocalDateTime processingDate;

    @Column(name = "processingStatus")
    private Integer processingStatus;

    @Column(name = "isRead")
    private Integer isRead;

    @Column(name = "user_id")
    private String userId;

    @Column(name = "manager_id")
    private String managerId;

//    @ManyToOne
//    @JoinColumn(name = "vehicle_id")
//    @EqualsAndHashCode.Exclude
//    @ToString.Exclude
//    @JsonIgnoreProperties(value = {"vehicleCategory", "user", "report", "bookingl"})
//    private Vehicle vehicle;

    public String getReportId() {
        return reportId;
    }

    public void setReportId(String reportId) {
        this.reportId = reportId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getVehiclePlateNumber() {
        return vehiclePlateNumber;
    }

    public void setVehiclePlateNumber(String vehiclePlateNumber) {
        this.vehiclePlateNumber = vehiclePlateNumber;
    }

    public LocalDateTime getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDateTime createDate) {
        this.createDate = createDate;
    }

    public LocalDateTime getProcessingDate() {
        return processingDate;
    }

    public void setProcessingDate(LocalDateTime processingDate) {
        this.processingDate = processingDate;
    }

    public Integer getProcessingStatus() {
        return processingStatus;
    }

    public void setProcessingStatus(Integer processingStatus) {
        this.processingStatus = processingStatus;
    }

    public Integer getIsRead() {
        return isRead;
    }

    public void setIsRead(Integer isRead) {
        this.isRead = isRead;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getManagerId() {
        return managerId;
    }

    public void setManagerId(String managerId) {
        this.managerId = managerId;
    }

//    public Vehicle getVehicle() {
//        return vehicle;
//    }
//
//    public void setVehicle(Vehicle vehicle) {
//        this.vehicle = vehicle;
//    }
}