package com.dpm.parkinght.dto.request;

import java.time.LocalDateTime;

import com.dpm.parkinght.dto.entity.User;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingRequest {

	String booking_Id;
	
	/** Id of driver*/
	User user;

	/** Id of vehicle*/
	String vehicle_Id;

	
	/** Day of starting parking*/
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss[.SSS][.SS][.S]")
	LocalDateTime start_Date;
	
	/** Day of ending parking*/
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss[.SSS][.SS][.S]")
	LocalDateTime end_Date;
	
	LocalDateTime create_Date;

	/** Id of position parking*/
	String parking_Slot_Id;
	
	String booking_Status;
	
	LocalDateTime update_Time;
}
