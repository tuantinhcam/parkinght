package com.dpm.parkinght.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dpm.parkinght.common.BaseResponse;
import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.dto.entity.Booking;
import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.request.BookingRequest;
import com.dpm.parkinght.dto.request.CheckSlotRequest;
import com.dpm.parkinght.repository.BookingRepository;
import com.dpm.parkinght.service.BookingService;
import com.dpm.parkinght.service.ParkingSlotService;
import com.dpm.parkinght.service.UserService;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/api")
public class BookingController {

	@Autowired
	private BookingService bookingService;

	@Autowired
	private ParkingSlotService parkingSlotService;
	
	@Autowired
	private BookingRepository bookingRepository;

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	private UserService userService;

	@PostMapping("/booking")
	public BaseResponse<Booking> bookingParkingSpot(@RequestBody BookingRequest bookingRequest, HttpSession session,
			Authentication authentication) {
		User user = userService.findByPhone(authentication.getName());
		List<String> existSlot = parkingSlotService.checkAvailableSlot(bookingRequest.getStart_Date(), bookingRequest.getEnd_Date());
		if(!existSlot.isEmpty()) {
			return BaseResponse.badRequest("Cho nay da duoc dat tai khung gio cua ban");
		}
		if (user != null) {
			Booking booking = modelMapper.map(bookingRequest, Booking.class);
			booking.setUser(user);
			session.setAttribute("bookingInitiationRequest", booking);
			return BaseResponse.ok(bookingService.insertBooking(booking, authentication));
		} else {
			return BaseResponse.badRequest("Dat cho that bai");
		}
	}

	@GetMapping("cancel/{bookingID}")
	public BaseResponse<?> cancelBooking(@PathVariable String bookingID, Authentication authentication) throws AccountNotFoundException {
			User user = userService.findByPhone(authentication.getName());
			if (user != null) {
		return BaseResponse.ok(bookingService.cancelBooking(bookingID ,authentication));
			}
			 return BaseResponse.badRequest("Khong tim thay booking");
	}

	@PostMapping("/slot")
	public ResponseEntity<List<String>> availableSlot(@RequestBody CheckSlotRequest checSlotRequest) {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			LocalDateTime startDate = LocalDateTime.parse(checSlotRequest.getStart_Date(), formatter);
			LocalDateTime endDate = LocalDateTime.parse(checSlotRequest.getEnd_Date(), formatter);
			System.out.println(startDate.toString());
			List<String> slotAvaiList = parkingSlotService.checkAvailableSlot(startDate, endDate);
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(slotAvaiList);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/getBookingForAd")
	public BaseResponse<?> create(Authentication authentication) {
		return BaseResponse.ok(bookingService.getAll(authentication));
	}
	
	@GetMapping("/getBookingForUser/{bookingId}")
	public BaseResponse<?> getBookingInfo(@PathVariable String bookingId,  Authentication authentication){
		User user = userService.findByPhone(authentication.getName());
		if (user != null) {
			return BaseResponse.ok(bookingRepository.findByBooking_userId(bookingId ,user.getUserId()));
		}
		 return BaseResponse.badRequest("Khong tim thay booking");
	}
	
}
