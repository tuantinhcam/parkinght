package com.dpm.parkinght.filter;

import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PasswordFilter {
    public static boolean isValidPassword(String password) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(password);

        return matcher.matches();
    }

    public static String generateOTP() {
        Random random = new Random();
        String otp = random.ints(6, 0, 10).mapToObj(Integer::toString)
                .reduce((a, b) -> a + b).get();
        System.out.println("otp: " + otp);
        return otp;
    }
}
