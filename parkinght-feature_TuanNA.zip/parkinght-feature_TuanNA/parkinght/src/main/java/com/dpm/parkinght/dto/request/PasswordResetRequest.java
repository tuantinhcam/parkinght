package com.dpm.parkinght.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class PasswordResetRequest {
	@NotBlank(message = "Khong duoc de trong")
	String confirmPassword;
}
