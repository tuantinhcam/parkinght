package com.dpm.parkinght.enums;

import java.util.Arrays;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum Cost {

	PER_HOUR(15000), PER_NIGHT(20000), PER_MINUTES(1000);

	private double value;

	public Double getValue() {
		return value;
	}

	
	public static Cost of(String value) {
		
		return Arrays.stream(Cost.values())
		          .filter(c -> value.equals(c.getValue()))
		          .findFirst()
		          .orElse(null);
	}
	

}
