package com.dpm.parkinght.common;

import javax.security.auth.login.AccountNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;

import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.service.UserService;

public class UserHelper {

	@Autowired
	private UserService userService;
	
	public User getUserId(String phoneNumeber) throws AccountNotFoundException {
		if(phoneNumeber!=null) {
			User user = userService.findByPhone(phoneNumeber);
			return user;
		}
		else {
			throw new AccountNotFoundException();
		}
			
		
	}
}
