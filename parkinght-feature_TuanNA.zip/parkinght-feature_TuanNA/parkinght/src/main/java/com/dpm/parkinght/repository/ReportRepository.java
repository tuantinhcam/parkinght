package com.dpm.parkinght.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dpm.parkinght.dto.entity.Report;

public interface ReportRepository extends JpaRepository<Report, String> {
	List<Report> findAllByUserId(String userId);

	List<Report> findAllByIsRead(Integer isRead);
}
