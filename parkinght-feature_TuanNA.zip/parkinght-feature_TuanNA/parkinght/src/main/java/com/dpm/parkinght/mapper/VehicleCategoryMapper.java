package com.dpm.parkinght.mapper;


import java.time.LocalDateTime;
import java.util.UUID;

//import org.modelmapper.ModelMapper;

import com.dpm.parkinght.dto.entity.VehicleCategory;
import com.dpm.parkinght.dto.request.VehicleCategoryCreateRequest;

public class VehicleCategoryMapper {
    //private static final ModelMapper modelMapper = new ModelMapper();

    public static VehicleCategory convertToCategoryResponse(VehicleCategoryCreateRequest category) {
        VehicleCategory vehicleCategory = new VehicleCategory();
        vehicleCategory.setVehicleCategoryId(UUID.randomUUID().toString());
        vehicleCategory.setVehicleCategoryName(category.getVehicleCategoryName());
        vehicleCategory.setDelDate(null);
        vehicleCategory.setDelFlag(false);
        vehicleCategory.setUpdateTime(LocalDateTime.now());
        vehicleCategory.setDelUserId(null);
        return vehicleCategory;
    }
}