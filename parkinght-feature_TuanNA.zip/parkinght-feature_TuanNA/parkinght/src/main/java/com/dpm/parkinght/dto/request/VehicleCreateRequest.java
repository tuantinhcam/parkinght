package com.dpm.parkinght.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VehicleCreateRequest {
    private String plateNumber;
    private String vehicleName;
    private Integer numberOfFouls;
    private String categoryId;
    private String userId;
       
}
