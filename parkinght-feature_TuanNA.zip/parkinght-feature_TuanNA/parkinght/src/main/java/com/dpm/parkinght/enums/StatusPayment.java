package com.dpm.parkinght.enums;

import java.util.Arrays;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum StatusPayment {

	UNPAID("0","UnPaid"),PAID("1", "Paid");

	private String value;
	private String display;

	public String getValue() {
		return value;
	}

	public String getDisplay() {
		return display;
	}
	
	public static StatusPayment of(String value) {
		
		return Arrays.stream(StatusPayment.values())
		          .filter(c -> value.equals(c.getValue()))
		          .findFirst()
		          .orElse(null);
	}
	

}
