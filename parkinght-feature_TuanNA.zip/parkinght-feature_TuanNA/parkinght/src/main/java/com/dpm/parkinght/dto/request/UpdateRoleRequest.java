package com.dpm.parkinght.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class UpdateRoleRequest {
	@NotBlank(message = "Khong duoc de trong id cua user")
	String userId;
	@NotBlank(message = "Khong duoc de trong role")
	String role;
}
