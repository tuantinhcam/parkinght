package com.dpm.parkinght.dto.request;

import com.dpm.parkinght.common.GetNotNull;
import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.filter.PasswordFilter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChangePasswordRequest {
    private String oldPass;
    private String newPass;


    public String getOldPass() {
        if (GetNotNull.isNull(oldPass)) {
            throw new LogicException("Mat khau cu chua duoc nhap");
        }
        return oldPass;
    }

    public void setOldPass(String oldPass) {
        this.oldPass = oldPass;
    }

    public String getNewPass() {
        if (GetNotNull.isNull(newPass)) {
            throw new LogicException("Mat khau moi chua duoc nhap");
        }
        return newPass;
    }

    public void setNewPass(String newPass) {
        if(!PasswordFilter.isValidPassword(newPass) || GetNotNull.isNull(newPass)){
            throw new LogicException("Mat khau khong hop le");
        }
        this.newPass = newPass;
    }
}