package com.dpm.parkinght.enums;

import java.util.Arrays;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum StatusBooking {

	ONGOING("0","ONGOING"),COMPLETED("1", "COMPLETED"), CANCELED("2", "CANCELED");

	private String value;
	private String display;

	public String getValue() {
		return value;
	}

	public String getDisplay() {
		return display;
	}
	
	public static StatusBooking of(String value) {
		
		return Arrays.stream(StatusBooking.values())
		          .filter(c -> value.equals(c.getValue()))
		          .findFirst()
		          .orElse(null);
	}
	

}
