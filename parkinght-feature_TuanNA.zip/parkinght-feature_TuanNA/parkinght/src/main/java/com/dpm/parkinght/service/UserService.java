package com.dpm.parkinght.service;

import java.security.Principal;
import java.util.List;

import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.request.ChangePasswordRequest;
import com.dpm.parkinght.dto.request.PasswordResetRequest;
import com.dpm.parkinght.dto.request.UserCreateRequest;
import com.dpm.parkinght.dto.request.UserUpdateRequest;
import com.dpm.parkinght.dto.response.UserResponse;

public interface UserService {
	// loadUserByUsername
	User save(UserCreateRequest request);

	boolean forgotPassword(String phoneNumber, PasswordResetRequest newPassword);

	UserResponse getUserInformation(String userId);

	UserResponse update(String userId, UserUpdateRequest updateRequest, Principal principal);

	User findByPhone(String phone);

	void updateLastLogin(String userId);

	boolean isDriver(String phone);

	boolean isManager(String phone);

	boolean isAdmin(String phone);

	List<User> getAll(Principal principal);

	User deleteUser(String id, Principal principal);

	User changePassword(String id, ChangePasswordRequest changePasswordRequest, Principal principal);

	int getTotalRegisterInDay();

	boolean updateRole(String id, String role, Principal principal);

}