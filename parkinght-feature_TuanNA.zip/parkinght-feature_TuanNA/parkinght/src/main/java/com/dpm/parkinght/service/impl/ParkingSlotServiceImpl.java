package com.dpm.parkinght.service.impl;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.dpm.parkinght.common.GetNotNull;
import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.dto.entity.ParkingSlot;
import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.entity.VehicleCategory;
import com.dpm.parkinght.dto.request.ParkingSlotCreateRequest;
import com.dpm.parkinght.dto.request.ParkingSlotUpdateRequest;
import com.dpm.parkinght.dto.response.VehicleCategoryResponse;
import com.dpm.parkinght.mapper.ParkingSlotMapper;
import com.dpm.parkinght.repository.ParkingSlotRepository;
import com.dpm.parkinght.repository.VehicleCategoryRepository;
import com.dpm.parkinght.service.ParkingSlotService;
import com.dpm.parkinght.service.UserService;

@Service
//@RequiredArgsConstructor

public class ParkingSlotServiceImpl implements ParkingSlotService {

	private ParkingSlotRepository parkingSlotRepository;

	private UserService userService;
	
	private VehicleCategoryRepository vehicleCategoryRepository;

	@Autowired
	public ParkingSlotServiceImpl(ParkingSlotRepository parkingSlotRepository, UserService userService, VehicleCategoryRepository vehicleCategoryRepository) {
		this.parkingSlotRepository = parkingSlotRepository;
		this.userService = userService;
		this.vehicleCategoryRepository = vehicleCategoryRepository;
	}

	public ParkingSlotServiceImpl(ParkingSlotRepository parkingSlotRepository) {
		this.parkingSlotRepository = parkingSlotRepository;
	}

	@Override
	public List<String> checkAvailableSlot(LocalDateTime startDate, LocalDateTime endDate) {
		return parkingSlotRepository.checkAvailableSlot(startDate, endDate);

	}

	@Override
	public ParkingSlot findParkingSlotByBookingId(String bookingId) {
		return parkingSlotRepository.findSlotByBookingId(bookingId);
	}

	@Override
	public List<ParkingSlot> getAll(Principal principal) {
		if (userService.isDriver(principal.getName())) {
			// driver view ban ghi chua xoa
			return parkingSlotRepository.findAllByDelFlag(false);
		} else {
			// admin+manager view all
			return parkingSlotRepository.findAll();
		}
	}

	@Override
	public ParkingSlot save(ParkingSlotCreateRequest request, Principal principal) {
		if (userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		if (GetNotNull.isNull(request.getName()) || GetNotNull.isNull(request.getArea())
				|| request.getArea().length() > 50 || request.getName().length() > 30) {
			throw new LogicException("Insert fail!");
		}
		ParkingSlot parkingSlot = ParkingSlotMapper.convertToParkingSlot(request);
		// check trung duong so 1 thi chi co 1 khu A
		ParkingSlot slot = parkingSlotRepository.findByAreaAndAndName(parkingSlot.getArea(), parkingSlot.getName());
		if (slot != null) {
			throw new LogicException("Duplicate Area with Name");
		}
		return parkingSlotRepository.save(parkingSlot);
	}

	@Override
	public ParkingSlot findById(Principal principal, String id) {
		ParkingSlot parkingSlot = parkingSlotRepository.findById(id)
				.orElseThrow(() -> new LogicException("Not found parking slot with id: " + id));
		if (userService.isDriver(principal.getName())) {
			if (parkingSlot.getDelFlag()) {
				throw new LogicException("Not found parking slot with id: " + id);
			}
		}
		return parkingSlot;
	}

	@Override
	public ParkingSlot deleteParkingSlot(String id, Principal principal) {
		if (userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		ParkingSlot vehicle = findById(principal, id);
		vehicle.setUpdateTime(LocalDateTime.now());
		vehicle.setDelFlag(true);
		vehicle.setDelDate(LocalDateTime.now());
		User user = userService.findByPhone(principal.getName());
		vehicle.setDelUserId(user.getUserId());
		return parkingSlotRepository.save(vehicle);
	}

	@Override
	public ParkingSlot update(ParkingSlotUpdateRequest request, Principal principal) {
		if (userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		ParkingSlot parkingSlot = findById(principal, request.getParkingSlotId());
		// check trung duong so 1 thi chi co 1 khu A
//		ParkingSlot slot = parkingSlotRepository.findByAreaAndAndName(request.getArea(), request.getName());
//		if (slot != null) {
//			throw new LogicException("Duplicate Area with Name");
//		}
		BeanUtils.copyProperties(request, parkingSlot, GetNotNull.getNullPropertyNames(request));
		VehicleCategory vehicleCategory = vehicleCategoryRepository.findById(request.getVehicleCategory()).orElseThrow(
				() -> new LogicException("Not found vehicle category with id: " + request.getVehicleCategory()));
		parkingSlot.setVehicleCategory(vehicleCategory);
		parkingSlot.setUpdateTime(LocalDateTime.now());
		return parkingSlotRepository.save(parkingSlot);
	}

	@Override
	public List<ParkingSlot> findByArea(Principal principal, String area) {
		return parkingSlotRepository.findByArea(area);
	}

	@Override
	@Scheduled(fixedRate = 60000)
	public void scheduleCheckingStatusSlot() {
		List<String> parkingSlotList = getExpiredSlot();
		updateStatusSlot(parkingSlotList);
		System.out.println("Update thanh cong");
	}

	@Override
	public List<String> getExpiredSlot() {
		return parkingSlotRepository.getExpiredSlot();
	}

	@Override
	public int updateStatusSlot(List<String> parkingSlot) {
		return parkingSlotRepository.updateStatusSlot(parkingSlot);
	}

	@Override
	public List<String> findAllArea(Principal principal) {
		if (userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		return parkingSlotRepository.findAllArea();
	}
	@Override
	 public List<VehicleCategoryResponse> findAllByVehicleCategory(String vehicleCategoryId, Principal principal) {
		VehicleCategory vehicleCategory = vehicleCategoryRepository.findById(vehicleCategoryId)
				.orElseThrow(() -> new LogicException("Not found vehicle category with id: " + vehicleCategoryId));
		if (userService.isDriver(principal.getName())) {
			 return parkingSlotRepository.findAreaByVehicleCategoryAndDelFlag(vehicleCategoryId, false);
		} else {
			 return parkingSlotRepository.findAreaByVehicleCategory(vehicleCategoryId);
		}
	}
}