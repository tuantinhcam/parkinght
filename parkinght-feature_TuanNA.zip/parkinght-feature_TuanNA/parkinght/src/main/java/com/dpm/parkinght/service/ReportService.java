package com.dpm.parkinght.service;

import com.dpm.parkinght.dto.entity.Report;
import com.dpm.parkinght.dto.request.ReportCreateRequest;
import com.dpm.parkinght.dto.request.ReportUpdateRequest;

import java.security.Principal;
import java.util.List;

public interface ReportService {
	List<Report> getAll(Principal principal);

	Report findById(String id);

	List<Report> getReportByDriver(Principal principal);

	Report save(ReportCreateRequest request, Principal principal);

	Report update(Principal principal, ReportUpdateRequest reportUpdateRequest);

	List<Report> getUnreadReport(Principal principal, Integer isRead);

	Integer countUnreadReport(Principal principal, Integer isReadStatus);
}