package com.dpm.parkinght.common.errors;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ErrorRes {
    private String data;
    private int statusCode;
    private String message;
}