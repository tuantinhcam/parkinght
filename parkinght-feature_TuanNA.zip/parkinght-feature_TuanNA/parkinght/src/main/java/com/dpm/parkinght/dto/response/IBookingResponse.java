package com.dpm.parkinght.dto.response;

import java.time.LocalDateTime;

import com.dpm.parkinght.enums.StatusBooking;

public interface IBookingResponse {
	String getId();
	String getArea();
	String getAreaName();
	Long getAmount();
	StatusBooking getStatus();
	Float getDuration_hours();
	LocalDateTime getCreateDate();
}
