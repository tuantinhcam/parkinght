package com.dpm.parkinght.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PaymentRequest {
	Long amount;
	String bookingId;
}
