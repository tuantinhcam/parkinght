package com.dpm.parkinght.repository;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.dpm.parkinght.dto.entity.Booking;
import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.response.IBookingResponse;

public interface BookingRepository extends JpaRepository<Booking, String> {

	@Query(value = "SELECT bk.booking_id FROM tbl_booking bk ORDER BY bk.booking_id DESC LIMIT 1", nativeQuery = true)
	String getLastBookingId();
	
	@Query(value = "SELECT substr(?1,-4, 4) from tbl_booking bk", nativeQuery = true)
	String getLastNumID(String bookingId);
	
	@Query(value = "SELECT COUNT(1) from tbl_booking bk where bk.booking_id = ?1", nativeQuery = true)
	int checkUniqueId(String bookingId);
	
	@Query(value = "SELECT * from tbl_booking bk where bk.booking_id = ?1 and bk.user_id = ?2", nativeQuery = true)
	Booking findByBooking_userId(String bookingId, String userId);
	
	@Query(value = "SELECT tbl_booking.booking_id AS id,\n"
			+ "tbl_parking_slot.parking_slot_area AS area,\n"
			+ "tbl_parking_slot.parking_slot_name AS areaName,\n"
			+ "tbl_booking.booking_total AS amount,\n"
			+ "tbl_booking.booking_status AS status,\n"
			+ "ROUND(TIMESTAMPDIFF(second, tbl_booking.start_date, tbl_booking.end_date)/3600, 2) AS duration_hours, tbl_booking.create_date AS createDate FROM tbl_booking\r\n"
			+ "JOIN tbl_parking_slot \r\n"
			+ "ON tbl_booking.parking_slot_id = tbl_parking_slot.parking_slot_id\r\n"
			+ "JOIN tbl_user\r\n"
			+ "ON tbl_booking.user_id = tbl_user.user_id\r\n"
			+ "WHERE tbl_booking.booking_status = ?1\r\n"
			+ "AND tbl_user.phone_number = ?2", nativeQuery = true)
	List<IBookingResponse> getBookingByStatus(String status,String phoneNumber, Principal principal);

	
	List<Booking> findAllByUser(User user);
}
