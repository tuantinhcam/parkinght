package com.dpm.parkinght.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CheckInResponse {
	private String status;
	private String messsage;
	private String startDate;
	private String endDate;
	private String checkInDate;
	private String durianTime;

}
