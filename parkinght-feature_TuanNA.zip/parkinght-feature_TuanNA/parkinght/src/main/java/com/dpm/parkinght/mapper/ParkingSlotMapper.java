package com.dpm.parkinght.mapper;


import java.time.LocalDateTime;
import java.util.UUID;

import org.modelmapper.ModelMapper;

import com.dpm.parkinght.dto.entity.ParkingSlot;
import com.dpm.parkinght.dto.request.ParkingSlotCreateRequest;
import com.dpm.parkinght.enums.StatusParkingSlot;

public class ParkingSlotMapper {
    private static final ModelMapper modelMapper = new ModelMapper();

    public static ParkingSlot convertToParkingSlot(ParkingSlotCreateRequest request) {
        ParkingSlot parkingSlot = new ParkingSlot();
        parkingSlot.setParkingSlotId(UUID.randomUUID().toString());
        parkingSlot.setArea(request.getArea());
        parkingSlot.setName(request.getName());
        parkingSlot.setPricePerHour(request.getPricePerHour());
        parkingSlot.setParking_Slot_Status(StatusParkingSlot.AVAILABLE); //default
        parkingSlot.setUpdateTime(LocalDateTime.now());
        parkingSlot.setDelFlag(false);
        parkingSlot.setDelDate(null);
        parkingSlot.setDelUserId(null);
        return parkingSlot;
    }
}