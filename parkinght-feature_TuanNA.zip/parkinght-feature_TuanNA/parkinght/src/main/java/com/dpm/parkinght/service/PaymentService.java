package com.dpm.parkinght.service;

import java.util.List;

import com.dpm.parkinght.dto.entity.Payment;
import com.dpm.parkinght.dto.response.IMonthlyPayment;


public interface PaymentService {
	
	public Payment insertPayment(Payment payment);
	
	Long totalPaymentInDay ();
	
	List<IMonthlyPayment> totalPaymentInMonth();
}
