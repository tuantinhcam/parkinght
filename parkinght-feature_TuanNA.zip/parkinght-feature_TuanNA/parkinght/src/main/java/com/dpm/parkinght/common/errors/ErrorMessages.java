package com.dpm.parkinght.common.errors;

//package com.dpm.parkinght.common.errors;
//
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//
////@AllArgsConstructor
////public enum ErrorMessages {
////    INTERNAL_SERVER_ERROR("INTERNAL_SERVER_ERROR"),
////    USER_USERNAME_PASSWORD_ERROR("USER_USERNAME_PASSWORD_ERROR"),
////    USER_USERNAME_ALREADY_ERROR("USER_USERNAME_EXIT_ERROR"), // Username password ko hợp lệ
////    ROLE_NOT_FOUND_ERROR("ROLE_NOT_FOUND_ERROR"), // call otp error
////    USER_NOT_FOUND_ERROR("USER_NOT_FOUND_ERROR"); // call otp error
////    public String getMessage() {
////		return message;
////	}
////
////	private final String message;
////
////	private ErrorMessages(String message) {
////		this.message = message;
////	}
////
////}