package com.dpm.parkinght.service.impl;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.dpm.parkinght.common.GetNotNull;
import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.request.ChangePasswordRequest;
import com.dpm.parkinght.dto.request.PasswordResetRequest;
import com.dpm.parkinght.dto.request.UserCreateRequest;
import com.dpm.parkinght.dto.request.UserUpdateRequest;
import com.dpm.parkinght.dto.response.UserResponse;
import com.dpm.parkinght.enums.Role;
import com.dpm.parkinght.filter.PasswordFilter;
import com.dpm.parkinght.filter.PhoneFilter;
import com.dpm.parkinght.mapper.UserMapper;
import com.dpm.parkinght.repository.UserRepository;
import com.dpm.parkinght.service.UserService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
	@Autowired
	private PasswordEncoder encoder;

	@Autowired
	private UserRepository userRepository;
	

	public UserServiceImpl(PasswordEncoder encoder, UserRepository userRepository) {
		this.encoder = encoder;
		this.userRepository = userRepository;
	}

	@Override
	public User save(UserCreateRequest request) {
		User user = UserMapper.convertToUser(request);
		user.setUserId(UUID.randomUUID().toString());
		if (!PhoneFilter.isValidPhoneNumber(user.getPhoneNumber())) {
			throw new LogicException("So dien thoai la 10 so va bat dau bang so 0");
		}
		if (!PasswordFilter.isValidPassword(request.getPassword())) {
			throw new LogicException("Mat khau it nhất 8 kí tự bao gom 1 chữ cái viết hoa,1 số,1 kí tự đặc biệt");
		}
		user.setCreatedDate(LocalDateTime.now());
		user.setUpdateTime(LocalDateTime.now());
		user.setPassword(encoder.encode(request.getPassword()));
		user.setDelFlag(false);
		// check exist phone / email
		Optional<User> user1 = userRepository.findByPhoneNumber(user.getPhoneNumber());
		User existEmail = userRepository.findByEmail(user.getEmail());
		if (user1.isPresent()) {
			throw new LogicException("Exist phoneNumber");
		}
		if (existEmail != null) {
			throw new LogicException("Exist email");
		}
		// check tuoi
		if (GetNotNull.isNull(request.getBirthday().toString())) {
			throw new LogicException("Chưa nhập ngày sinh");
		}
		if (new Date().getYear() - request.getBirthday().getYear() < 18) {
			throw new LogicException("Chưa đủ tuổi");
		}
		// Role role = roleRepository.findByRoleName(request.getRole());
		user.setRole(Role.DRIVER);
		return userRepository.save(user);
	}

	@Override
	public boolean forgotPassword(String phoneNumber, PasswordResetRequest passwordReset) {
		User user = userRepository.findByPhoneNumber(phoneNumber).orElseThrow(() 
				-> new LogicException("Not found user with id: " + phoneNumber));
		if (!PasswordFilter.isValidPassword(passwordReset.getConfirmPassword())
				|| GetNotNull.isNull(passwordReset.getConfirmPassword())) {
			throw new LogicException("Mat khau khong hop le");
		}
		user.setPassword(encoder.encode(passwordReset.getConfirmPassword()));
		user.setUpdateTime(LocalDateTime.now());
		if(userRepository.save(user)!=null) {
			return true;
		}
		else return false;
	}

	@Override
	public UserResponse getUserInformation(String userId) {
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new LogicException("Not found user with id: " + userId));
		return UserMapper.convertToUserResponse(user);
	}

	@Override
	public UserResponse update(String userId, UserUpdateRequest updateRequest, Principal principal) {
		if (isAdmin(principal.getName())) {
			throw new LogicException("Not Permission");
		}
		// check id
		if ("".equals(userId) || userId == null || !userId.equals(updateRequest.getUserId())) {
			throw new LogicException("Invalid ID: " + userId);
		}

		User user = userRepository.findById(userId)
				.orElseThrow(() -> new LogicException("Not found user with id: " + userId));
		BeanUtils.copyProperties(updateRequest, user, GetNotNull.getNullPropertyNames(updateRequest));
		user.setUpdateTime(LocalDateTime.now()); // set thoi gian update
		User updatedUser = userRepository.save(user);
		return UserMapper.convertToUserResponse(updatedUser);
	}

	@Override
	public User findByPhone(String phone) {
		return userRepository.findByPhoneNumber(phone)
				.orElseThrow(() -> new LogicException("Not found user with phone: " + phone));
	}

	@Override
	public void updateLastLogin(String userId) {
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new LogicException("Not found user with id: " + userId));
		user.setLastLogin(LocalDateTime.now());
		userRepository.save(user);
	}

	@Override
	public boolean isDriver(String phone) {
		User user = findByPhone(phone);
		return user.getRole().getDisplay().equalsIgnoreCase("DRIVER");
	}

	@Override
	public boolean isManager(String phone) {
		User user = findByPhone(phone);
		return user.getRole().getDisplay().equalsIgnoreCase("MANAGER");
	}

	@Override
	public boolean isAdmin(String phone) {
		User user = findByPhone(phone);
		return user.getRole().getDisplay().equalsIgnoreCase("ADMIN");
	}

	@Override
	public List<User> getAll(Principal principal) {
		if (!isAdmin(principal.getName())) {
			throw new LogicException("Not permission");
		}
		return userRepository.findAll();
	}

	@Override
	public User deleteUser(String id, Principal principal) {
		if (!isAdmin(principal.getName())) {
			throw new LogicException("Not Permission");
		}
		User user = userRepository.findById(id).orElseThrow(() -> new LogicException("Not found user with id: " + id));
		user.setUpdateTime(LocalDateTime.now());
		user.setDelFlag(true);
		user.setDelDate(LocalDateTime.now());
		User deleteUser = findByPhone(principal.getName());
		user.setDelUserId(deleteUser.getUserId());
		return userRepository.save(user);
	}

	@Override
	public User changePassword(String id, ChangePasswordRequest changePasswordRequest, Principal principal) {
		User user = userRepository.findById(id).orElseThrow(() -> new LogicException("Not found user with id: " + id));
		if (!encoder.matches(changePasswordRequest.getOldPass(), user.getPassword())) {
			throw new LogicException("Mat khau sai");
		}
		if (!PasswordFilter.isValidPassword(changePasswordRequest.getNewPass())
				|| GetNotNull.isNull(changePasswordRequest.getNewPass())) {
			throw new LogicException("Mat khau khong hop le");
		}
		user.setPassword(encoder.encode(changePasswordRequest.getNewPass()));
		user.setUpdateTime(LocalDateTime.now());
		return userRepository.save(user);
	}

	@Override
	public int getTotalRegisterInDay() {
		return userRepository.getTotalRegisterInDay();
	}

	@Override
	public boolean updateRole(String id, String role, Principal principal) {
		if (!isAdmin(principal.getName())) {
			throw new LogicException("Ban khong phai la admin");
		}
		User user = userRepository.findById(id).orElseThrow(() -> new LogicException("Khong the tim thay nguoi dung voi id: " + id));
		if (role.equals("DRIVER")) {
			if (isDriver(principal.getName())) {
				throw new LogicException("User da la DRIVER");
			} else {
				user.setRole(Role.DRIVER);
				userRepository.save(user);
				return true;
			}

		} else if (role.equals("MANAGER")) {
			if (isDriver(principal.getName())) {
				throw new LogicException("User da la MANAGER");
			} else {
				user.setRole(Role.MANAGER);
				 userRepository.save(user);
				 return true;
			}

		}
		return false;

	}
}
