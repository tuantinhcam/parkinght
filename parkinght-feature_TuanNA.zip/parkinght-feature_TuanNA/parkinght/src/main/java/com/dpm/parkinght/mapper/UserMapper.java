package com.dpm.parkinght.mapper;

import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.request.UserCreateRequest;
import com.dpm.parkinght.dto.response.UserResponse;
import org.modelmapper.ModelMapper;

public class UserMapper {
    private static final ModelMapper modelMapper = new ModelMapper();

    public static UserResponse convertToUserResponse(User user) {
//        UserResponse userResponse=new UserResponse();
//        userResponse.setUserId(user.getUserId());
//        userResponse.setFullName(user.getFullName());
//        userResponse.setBirthday(user.getBirthday());
//        userResponse.setPhoneNumber(user.getPhoneNumber());
//        userResponse.setEmail(user.getEmail());
//        userResponse.setPassword(user.getPassword());
//        userResponse.setCreatedDate(user.getCreatedDate());
//        userResponse.setUpdateTime(user.getUpdateTime());
//        userResponse.set
//        userResponse.set
        return modelMapper.map(user, UserResponse.class);
    }

    public static User convertToUser(UserCreateRequest request) {
        return modelMapper.map(request, User.class);
    }
}