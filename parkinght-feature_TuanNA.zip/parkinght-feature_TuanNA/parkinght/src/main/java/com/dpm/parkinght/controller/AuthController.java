package com.dpm.parkinght.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dpm.parkinght.common.BaseResponse;
import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.request.AuthRequest;
import com.dpm.parkinght.dto.request.OTPSendRequest;
import com.dpm.parkinght.dto.request.ValidateOTPRequest;
import com.dpm.parkinght.dto.response.AuthResponse;
import com.dpm.parkinght.dto.response.OTPResponse;
import com.dpm.parkinght.enums.StatusOTP;
import com.dpm.parkinght.service.OTPTwilioService;
import com.dpm.parkinght.service.UserService;
import com.dpm.parkinght.service.impl.JwtService;
import com.dpm.parkinght.service.impl.UserInfoServiceImpl;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/auth")
//@RequiredArgsConstructor
public class AuthController {

	// @Autowired
	private final UserInfoServiceImpl service;

	// @Autowired
	private final JwtService jwtService;

	// @Autowired
	private final AuthenticationManager authenticationManager;

	@Autowired
	private OTPTwilioService twilioService;

	@Autowired
	private UserService userService;

	@Autowired
	public AuthController(UserInfoServiceImpl service, JwtService jwtService,
			AuthenticationManager authenticationManager) {
		this.service = service;
		this.jwtService = jwtService;
		this.authenticationManager = authenticationManager;
	}

	@GetMapping("/welcome")
	public String welcome() {
		return "Welcome this endpoint is not secure";
	}

	@PostMapping("/addNewUser")
	public String addNewUser(@RequestBody User userInfo) {
		return service.addUser(userInfo);
	}

//	@PostMapping(value = "/requestOTP", produces = MediaType.APPLICATION_JSON_VALUE)
//	public BaseResponse<OTPResponse> sendOTPSms(@RequestBody AuthRequest authRequest, HttpSession session,
//			Authentication authentication) {
//		try {
//			authentication = authenticationManager.authenticate(
//					new UsernamePasswordAuthenticationToken(authRequest.getPhoneNumber(), authRequest.getPassword()));
//
//		} catch (Exception e) {
//			return BaseResponse.error(null, HttpStatus.UNAUTHORIZED.value(), "Đăng nhập thất bại!");
//		}
//		if (authentication.isAuthenticated()) {
//			OTPSendRequest otpRequest = new OTPSendRequest(authRequest.getPhoneNumber());
//			OTPResponse res = twilioService.sendOTPPassword(otpRequest);
//			if (StatusOTP.DELIVERED.equals(res.getStatus())) {
//				session.setAttribute("phoneNumber", otpRequest.getDestPhoneNumber());
//				return BaseResponse.ok(res);
//			} else {
//				res.setCode("401");
//				res.setMessage("Loi khi gui otp");
//				return  BaseResponse.badRequest(res);
//			}
//		} else {
//			return BaseResponse.error(null,HttpStatus.UNAUTHORIZED.value(), "Đăng nhập thất bại!");
//		}
//
//	}
//
//	@PostMapping(value = "/validateOtp")
//	public ResponseEntity<?> validateOtp(@RequestBody ValidateOTPRequest otpRequest, HttpSession session)
//			throws LogicException {
//
//		final String SUCCESS = "OTP hop le!";
//
//		final String FAIL = "Otp khong hop le. Vui long thu lai!";
//
//		String phoneNumber = session.getAttribute("phoneNumber").toString();
//		int otpNum = Integer.parseInt(otpRequest.getOtp());
//		if (otpNum >= 0) {
//			int serverOtp = twilioService.validateOTP(phoneNumber);
//
//			if (serverOtp > 0) {
//				if (otpNum == serverOtp) {
//					twilioService.clearOTP(phoneNumber);
//					AuthRequest authRequest = new AuthRequest();
//					authRequest.setPhoneNumber(phoneNumber);
//					return ResponseEntity.ok(jwtService.generateToken(authRequest.getPhoneNumber()));
//				} else {
//					return ResponseEntity.badRequest().body(FAIL);
//				}
//			} else {
//				return ResponseEntity.badRequest().body("Da co loi xay ra hoac OTP da het han su dung");
//
//			}
//		} else {
//			return ResponseEntity.badRequest().body(FAIL);
//
//		}
//	}

	@PostMapping("/generateToken")
	public BaseResponse<AuthResponse> authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
		Authentication authentication;
		try {
			authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getPhoneNumber(), authRequest.getPassword()));

		} catch (Exception e) {
			return BaseResponse.error(null, HttpStatus.UNAUTHORIZED.value(), "Đăng nhập thất bại!");
		}

		if (authentication.isAuthenticated()) {
			return BaseResponse.ok(jwtService.generateToken(authRequest.getPhoneNumber()));
		} else {
			return BaseResponse.error(null, HttpStatus.UNAUTHORIZED.value(), "Đăng nhập thất bại!");
		}
	}

	@GetMapping(value = "/logout")
	public @ResponseBody String logout(HttpServletRequest request, HttpServletResponse response) {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null) {
			String username = auth.getName();

			// Remove the recently used OTP from server.
			twilioService.clearOTP(username);

			new SecurityContextLogoutHandler().logout(request, response, auth);
		}

		return "redirect:/login?logout";
	}
}