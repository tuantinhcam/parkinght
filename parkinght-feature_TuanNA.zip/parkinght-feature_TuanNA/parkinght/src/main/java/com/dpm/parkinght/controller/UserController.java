package com.dpm.parkinght.controller;

import com.dpm.parkinght.common.BaseResponse;
import com.dpm.parkinght.dto.entity.ParkingSlot;
import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.request.ChangePasswordRequest;
import com.dpm.parkinght.dto.request.OTPSendRequest;
import com.dpm.parkinght.dto.request.UpdateRoleRequest;
import com.dpm.parkinght.dto.request.UserCreateRequest;
import com.dpm.parkinght.dto.request.UserUpdateRequest;
import com.dpm.parkinght.dto.response.UserResponse;
import com.dpm.parkinght.service.BookingService;
import com.dpm.parkinght.service.UserService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/user")
@Slf4j
//@RequiredArgsConstructor
public class UserController {
	// @Autowired
	private final UserService userService;
	private final BookingService bookingService;

	@Autowired
	public UserController(UserService userService, BookingService bookingService) {
		this.userService = userService;
		this.bookingService = bookingService;
	}

	@PostMapping("/create")
	public BaseResponse<User> create(@Valid @RequestBody UserCreateRequest request) {
		return BaseResponse.ok(userService.save(request));
	}

	@GetMapping("/get-by-id/{id}")
	public BaseResponse<UserResponse> userProfile(@PathVariable("id") String id) {
		return BaseResponse.ok(userService.getUserInformation(id));
	}

	@PutMapping("/update/{id}")
	public BaseResponse<UserResponse> update(@PathVariable("id") String id,
			@RequestBody UserUpdateRequest updateRequest, Principal principal) {
		return BaseResponse.ok(userService.update(id, updateRequest, principal));
	}

	@PutMapping("/update-last-login/{id}")
	public BaseResponse<?> updateLastLogin(@PathVariable("id") String id) {
		userService.updateLastLogin(id);
		return BaseResponse.ok();
	}

	@GetMapping("/get-all")
	public BaseResponse<List<User>> getAll(Principal principal) {
		return BaseResponse.ok(userService.getAll(principal));
	}

	@PutMapping("/delete/{id}")
	public BaseResponse<?> delete(@PathVariable("id") String id, Principal principal) {
		return BaseResponse.ok(userService.deleteUser(id, principal));
	}

	@PutMapping("/change-password/{id}")
	public BaseResponse<?> changPassword(@PathVariable("id") String id,
			@RequestBody ChangePasswordRequest changePasswordRequest, Principal principal) {
		return BaseResponse.ok(userService.changePassword(id, changePasswordRequest, principal));
	}

	@GetMapping("/getBooking/status")
	public BaseResponse<?> getBookingByStatus(@RequestParam String status, Authentication authentication) {
		if (status.equalsIgnoreCase("On Going")) {
			return BaseResponse.ok(bookingService.getBookingByStatus("0", authentication.getName(), authentication));
		} else if (status.equalsIgnoreCase("Completed")) {
			return BaseResponse.ok(bookingService.getBookingByStatus("1", authentication.getName(), authentication));
		} else if (status.equalsIgnoreCase("Canceled")) {
			return BaseResponse.ok(bookingService.getBookingByStatus("2", authentication.getName(), authentication));
		} else
			return BaseResponse.badRequest("Yeu cau khong hop le!");

	}

	@PutMapping("change-role/{id}")
	public BaseResponse<?> changeRoleUser(@Valid @RequestBody UpdateRoleRequest updateRoleRequest, BindingResult bindingResult, Authentication authentication) {
		if (bindingResult.hasErrors()) {
			return BaseResponse.badRequest("Co loi xay ra");
		}
		boolean successFlg = userService.updateRole(updateRoleRequest.getUserId(), updateRoleRequest.getRole(), authentication);
		if(successFlg) {
			return BaseResponse.ok();
		}
		return BaseResponse.badRequest("Co loi xay ra trong qua trinh cap nhat");
	}

}
