package com.dpm.parkinght.service;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;

import com.dpm.parkinght.dto.entity.ParkingSlot;
import com.dpm.parkinght.dto.request.ParkingSlotCreateRequest;
import com.dpm.parkinght.dto.request.ParkingSlotUpdateRequest;
import com.dpm.parkinght.dto.response.VehicleCategoryResponse;

public interface ParkingSlotService {

	List<ParkingSlot> getAll(Principal principal);

	ParkingSlot save(ParkingSlotCreateRequest request, Principal principal);

	ParkingSlot findById(Principal principal, String id);

	ParkingSlot deleteParkingSlot(String id, Principal principal);

	ParkingSlot update(ParkingSlotUpdateRequest updateRequest, Principal principal);

	List<ParkingSlot> findByArea(Principal principal, String area);

	List<String> checkAvailableSlot(LocalDateTime startDate, LocalDateTime endDate);

	ParkingSlot findParkingSlotByBookingId(String bookingId);

	List<String> getExpiredSlot();

	int updateStatusSlot(List<String> parkingSlot);

	void scheduleCheckingStatusSlot();

	List<String> findAllArea(Principal principal);

	List<VehicleCategoryResponse> findAllByVehicleCategory(String vehicleCategoryId, Principal principal);
}
