package com.dpm.parkinght.service;

import com.dpm.parkinght.dto.entity.Feedback;
import com.dpm.parkinght.dto.request.FeedbackRequest;

import java.security.Principal;
import java.util.List;

public interface FeedbackService {
	List<Feedback> getAll(Principal principal);

	Feedback findById(Principal principal, String id);

	Feedback save(String reportId, Principal principal);

	Feedback update(String id, FeedbackRequest updateRequest, Principal principal);

	List<Feedback> getUnreadReport(Principal principal, Integer isReadStatus);

	Integer countUnreadReport(Principal principal, Integer isReadStatus);

	List<Feedback> findByReport(Principal principal, String reportId);


}
