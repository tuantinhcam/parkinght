package com.dpm.parkinght.controller;

import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dpm.parkinght.common.BaseResponse;
import com.dpm.parkinght.dto.entity.Booking;
import com.dpm.parkinght.dto.response.CheckInResponse;
import com.dpm.parkinght.dto.response.CheckOutResponse;
import com.dpm.parkinght.enums.Cost;
import com.dpm.parkinght.repository.BookingRepository;
import com.dpm.parkinght.service.BookingService;

@RestController
@RequestMapping("/checkQR")
public class CheckViaQRController {

	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
	private BookingService bookingService;
	
	private DecimalFormat decimalFormat = new DecimalFormat("#,##0");

	@GetMapping("/checkInViaQR/{bookingID}")
	public BaseResponse<?> checkInViaQR(@PathVariable String bookingID) {
		String statusSuccess = "200";
		String statusFailed = "400";
		LocalDateTime currentCheckIn = LocalDateTime.now();

		if (bookingID.isBlank()) {
			return BaseResponse.badRequest("Vé đỗ không thể trống");
		}
		Optional<Booking> booking = bookingRepository.findById(bookingID);
		if (!booking.isPresent()) {
			return BaseResponse.badRequest("Vé đỗ không thể trống");
		}
		Booking bookingObject = booking.get();
		String startDate = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(bookingObject.getStart_Date());
		String endDate = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(bookingObject.getEnd_Date());
		String currentCheckInToString = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(currentCheckIn);

		if (LocalDateTime.now().isBefore(bookingObject.getStart_Date().minusMinutes(5))) {
			long minutes = ChronoUnit.MINUTES.between(currentCheckIn, bookingObject.getStart_Date()) - 5;
			String formatedMinutes = decimalFormat.format(minutes);
			String message = "Bạn tới sớm hơn thời gian cho phép " + minutes + " phút nên chưa được vào";
			CheckInResponse response = new CheckInResponse(statusFailed, message, startDate, endDate,
					currentCheckInToString, formatedMinutes);
			bookingService.updateCheckinTime(bookingObject, currentCheckIn);
			return BaseResponse.badRequest(response);
		} else if (LocalDateTime.now().isAfter(bookingObject.getEnd_Date())) {
			String message = "Vé của bạn đã hết hạn";
			CheckInResponse response = new CheckInResponse(statusFailed, message, startDate, endDate,
					currentCheckInToString, null);
			bookingService.updateCheckinTime(bookingObject, currentCheckIn);
			return BaseResponse.badRequest(response);
		} else {
			String message = "Bạn có thể vào";
			CheckInResponse response = new CheckInResponse(statusSuccess, message, startDate, endDate,
					currentCheckInToString, null);
			bookingService.updateCheckinTime(bookingObject, currentCheckIn);
			return BaseResponse.ok(response);
		}

	}

	@GetMapping("/checkOutViaQR/{bookingID}")
	public BaseResponse<?> checkOutViaQR(@PathVariable String bookingID) {
		if (bookingID.isBlank()) {
			return BaseResponse.badRequest("Vé đỗ không thể trống");
		}
		System.out.println(bookingID);
		Optional<Booking> booking = bookingRepository.findById(bookingID);
		if (!booking.isPresent()) {
			return BaseResponse.badRequest("Không tìm thấy vé đỗ");
		}
		String status = "200";
		LocalDateTime currentCheckout = LocalDateTime.now();
		Booking bookingObject = booking.get();
		String endDate = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(bookingObject.getEnd_Date());
		String currentCheckoutToString = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(currentCheckout);

		if (currentCheckout.isAfter(bookingObject.getEnd_Date().plusMinutes(5))) {

			float minutes = ChronoUnit.MINUTES.between(bookingObject.getEnd_Date(), currentCheckout) - 5;
			double penalty = minutes * (Cost.PER_MINUTES.getValue());

			String formatedMinutes = decimalFormat.format(minutes);
			String formatedPenalty = decimalFormat.format(penalty);

			String message = "Số tiền phải đóng là: " + formatedPenalty + " VND";
			String duration = "Số phút bị trễ là: " + formatedMinutes + " phút";
			CheckOutResponse response = new CheckOutResponse(status, message, endDate, currentCheckoutToString,
					duration);
			bookingService.updateCheckoutTime(bookingObject, currentCheckout);
			return BaseResponse.ok(response);
		} else {
			String message = "Xe của tài xế có thể đi ra";
			CheckOutResponse response = new CheckOutResponse(status, message, endDate, currentCheckoutToString, "0");
			bookingService.updateCheckoutTime(bookingObject, currentCheckout);
			return BaseResponse.ok(response);
		}

	}
}
