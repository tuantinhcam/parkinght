package com.dpm.parkinght.dto.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Entity
@Table(name = "tbl_feedback")
@Data
public class Feedback {
	@Id
	@Column(name = "feedback_id", unique = true, nullable = false, length = 25)
	private String feedBackId;

	@Column(name = "content", columnDefinition = "text")
	private String content;

	@Column(name = "rank_star")
	private Integer rankStar;

	@Column(name = "createDate")
	private LocalDateTime createDate;

	@Column(name = "isRead")
	private Integer isRead;

	@Column(name = "isFeedback")
	private Integer isFeedback;

	@ManyToOne
	@JoinColumn(name = "report_id")
	@EqualsAndHashCode.Exclude
	@ToString.Exclude
	@JsonIgnoreProperties(value = { "vehicle" })
	private Report report;

	public Feedback() {
	}

	public String getFeedBackId() {
		return feedBackId;
	}

	public void setFeedBackId(String feedBackId) {
		this.feedBackId = feedBackId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Integer getRankStar() {
		return rankStar;
	}

	public void setRankStar(Integer rankStar) {
		this.rankStar = rankStar;
	}

	public LocalDateTime getCreateDate() {
		return createDate;
	}

	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}

	public Integer getIsRead() {
		return isRead;
	}

	public void setIsRead(Integer isRead) {
		this.isRead = isRead;
	}

	public Integer getIsFeedback() {
		return isFeedback;
	}

	public void setIsFeedback(Integer isFeedback) {
		this.isFeedback = isFeedback;
	}

	public Report getReport() {
		return report;
	}

	public void setReport(Report report) {
		this.report = report;
	}
}