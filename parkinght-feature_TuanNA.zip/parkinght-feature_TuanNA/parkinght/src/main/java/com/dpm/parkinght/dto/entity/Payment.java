package com.dpm.parkinght.dto.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import com.dpm.parkinght.enums.PaymentMethod;
import com.dpm.parkinght.enums.StatusPayment;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_payment")
public class Payment {
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	@Column(name = "payment_id")
	private String payment_Id;

	@Column(name = "transaction_Id")
	private String transaction_Id;

	@OneToOne
	@JoinColumn(name = "booking_id", nullable = false)
	private Booking booking;

	@Column(name = "amount_paid")
	private Long total_Price;

	@Column(name = "payment_status")
	private StatusPayment status;

	@Column(name = "paid_by")
	private PaymentMethod payment_Method;

	@Column
	@CreationTimestamp
	private LocalDateTime create_Time;

}
