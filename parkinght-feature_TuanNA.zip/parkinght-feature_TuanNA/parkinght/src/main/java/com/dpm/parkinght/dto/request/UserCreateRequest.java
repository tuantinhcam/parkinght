package com.dpm.parkinght.dto.request;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserCreateRequest {
    private String fullName;
    private Date birthday;
    private String phoneNumber;
    private String email;
    private String password;
    private String role;    
    
}