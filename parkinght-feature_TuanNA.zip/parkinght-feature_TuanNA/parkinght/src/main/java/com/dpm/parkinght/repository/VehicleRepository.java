package com.dpm.parkinght.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.entity.Vehicle;
import com.dpm.parkinght.dto.entity.VehicleCategory;

public interface VehicleRepository extends JpaRepository<Vehicle, String> {
	List<Vehicle> findAllByVehicleCategory(VehicleCategory category);

	Vehicle findByPlateNumber(String plateNumber);

	List<Vehicle> findAllByDelFlag(boolean isDelFlag);
	
	List<Vehicle> findAllByUserAndDelFlag(User user, boolean isDelFlag);
}
