package com.dpm.parkinght.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VehicleUpdateRequest {
    @NotNull
    private String vehicleId;
    @NotNull
    private String plateNumber;
    @NotNull
    private String vehicleName;
    private Integer numberOfFouls;
    private String categoryId;
    private String userId;
    
}
