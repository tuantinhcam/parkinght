package com.dpm.parkinght.service;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.dpm.parkinght.dto.entity.Booking;
import com.dpm.parkinght.dto.response.IBookingResponse;

public interface BookingService {

	List<Booking> getAll(Principal principal);

	Booking findByIdForUser(String id, Principal principal);

	List<Booking> getBookingByDriver(Principal principal, String driverId);

	List<Booking> getBookingByDriverIsLogin(Principal principal);

	Booking insertBooking(Booking booking, Principal principal);

	Booking cancelBooking(String bookingID, Principal principal);
	
	List<IBookingResponse> getBookingByStatus(String status, String phoneNumber, Principal principal);
	
	void updateCheckinTime(Booking booking, LocalDateTime checkinTime);

	void updateCheckoutTime(Booking booking, LocalDateTime checkoutTime);
	
	
}
