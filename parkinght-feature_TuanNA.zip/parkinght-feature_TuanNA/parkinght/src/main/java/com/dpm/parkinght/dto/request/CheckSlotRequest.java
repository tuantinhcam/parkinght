package com.dpm.parkinght.dto.request;

import lombok.Data;

@Data
public class CheckSlotRequest {
	String start_Date;
	String end_Date;
}
