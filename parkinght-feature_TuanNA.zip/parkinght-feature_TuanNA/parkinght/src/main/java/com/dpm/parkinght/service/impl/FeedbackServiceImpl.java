package com.dpm.parkinght.service.impl;

import com.dpm.parkinght.common.GetNotNull;
import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.dto.entity.Feedback;
import com.dpm.parkinght.dto.entity.Report;
import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.request.FeedbackRequest;
import com.dpm.parkinght.repository.FeedbackRepository;
import com.dpm.parkinght.repository.ReportRepository;
import com.dpm.parkinght.repository.UserRepository;
import com.dpm.parkinght.service.FeedbackService;
import com.dpm.parkinght.service.UserService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class FeedbackServiceImpl implements FeedbackService {
	private final FeedbackRepository feedbackRepository;
	private final UserService userService;
	private final UserRepository userRepository;
	private final ReportRepository reportRepository;

	@Autowired
	public FeedbackServiceImpl(FeedbackRepository feedbackRepository, UserService userService,
			UserRepository userRepository, ReportRepository reportRepository) {
		this.feedbackRepository = feedbackRepository;
		this.userService = userService;
		this.userRepository = userRepository;
		this.reportRepository = reportRepository;
	}

	@Override
	public List<Feedback> getAll(Principal principal) {
		if (!userService.isAdmin(principal.getName())) {
			throw new LogicException("Not permission - Only admin");
		}
		return feedbackRepository.findAll();
	}

	@Override
	public Feedback findById(Principal principal, String id) {
		if (!userService.isAdmin(principal.getName())) {
			throw new LogicException("Not permission - only admin");
		}
		return feedbackRepository.findById(id)
				.orElseThrow(() -> new LogicException("Not found feedback with id: " + id));
	}

	@Override
	public Feedback save(String reportId, Principal principal) {
		Report report = reportRepository.findById(reportId)
				.orElseThrow(() -> new LogicException("Not found report with id: " + reportId));
		if (!userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission - only driver");
		}
		Feedback feedback = new Feedback();
		feedback.setFeedBackId(UUID.randomUUID().toString());
		feedback.setContent(null);
		feedback.setRankStar(0);
		feedback.setCreateDate(LocalDateTime.now());
		feedback.setIsFeedback(0);
		feedback.setIsFeedback(0);
		feedback.setReport(report);
		return feedbackRepository.save(feedback);
	}

	@Override
	public Feedback update(String id, FeedbackRequest updateRequest, Principal principal) {

		 Report report = reportRepository.findById(id).orElseThrow(() -> new LogicException("Not found report with id: " + id));

	        List<Feedback> fReport = feedbackRepository.findAllByReport(report);
	        if (fReport == null) {
	            throw new LogicException("Khong tim thay feedback voi report nay.");
	        }
	        Feedback feedback = fReport.get(0);
	        if(feedback==null) {
	            throw new LogicException("Not found feedback with  report id: " + id);
	        }
	        if (userService.isDriver(principal.getName())) {
	            feedback.setIsFeedback(1);
	            BeanUtils.copyProperties(updateRequest, feedback, GetNotNull.getNullPropertyNames(updateRequest));
	        } else if (userService.isAdmin(principal.getName())) {
	            feedback.setIsRead(1);
	        } else {
	            throw new LogicException("Not permission");
	        }
	        return feedbackRepository.save(feedback);
	}

	@Override
	public List<Feedback> getUnreadReport(Principal principal, Integer isReadStatus) {
		if (!userService.isAdmin(principal.getName())) {
			throw new LogicException("Not permission - only admin");
		}
		return feedbackRepository.findAllByIsRead(isReadStatus);
	}

	@Override
	public Integer countUnreadReport(Principal principal, Integer isReadStatus) {
		if (!userService.isAdmin(principal.getName())) {
			throw new LogicException("Not permission - only admin");
		}
		return getUnreadReport(principal, isReadStatus).size();
	}

	@Override
	public List<Feedback> findByReport(Principal principal, String reportId) {
		Report report = reportRepository.findById(reportId)
				.orElseThrow(() -> new LogicException("Không tìm thấy report với id: " + reportId));
		if (userService.isDriver(principal.getName())) {
			User user = userService.findByPhone(principal.getName());
			return feedbackRepository.findAllByReportAndDriver(user.getUserId(), reportId);
		} else {
			return feedbackRepository.findAllByReport(report);
		}
	}

}
