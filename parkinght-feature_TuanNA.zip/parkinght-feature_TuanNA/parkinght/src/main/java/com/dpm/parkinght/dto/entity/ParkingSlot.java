package com.dpm.parkinght.dto.entity;

import java.time.LocalDateTime;

import com.dpm.parkinght.enums.StatusParkingSlot;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_parking_slot")
public class ParkingSlot {
	@Id
	@Column(name = "parking_slot_id")
	private String parkingSlotId;

	@Column(name = "parking_slot_area")
	private String area;

	@Column(name = "parking_slot_name")
	private String name;

	@Column(name = "price_Per_Hour")
	private Double pricePerHour;

	@Column(name = "parking_slot_status")
	private StatusParkingSlot parking_Slot_Status;

	@Column(name = "update_time")
	private LocalDateTime updateTime;

	@Column(name = "del_flag")
	private Boolean delFlag;

	@Column(name = "del_date")
	private LocalDateTime delDate;

	@Column(name = "del_user_id")
	private String delUserId;
	
	@ManyToOne
    @JoinColumn(name = "vehicle_category_id") // thông qua khóa ngoại vehicle_category_id
    private VehicleCategory vehicleCategory;
}
