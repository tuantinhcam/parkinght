package com.dpm.parkinght.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CheckOutResponse {
	private String status;
	private String messsage;
	private String endDate;
	private String checkOutDate;
	private String duriantime;

}
