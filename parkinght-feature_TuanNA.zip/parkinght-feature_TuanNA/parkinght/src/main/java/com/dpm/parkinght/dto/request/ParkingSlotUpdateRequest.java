package com.dpm.parkinght.dto.request;

import com.dpm.parkinght.enums.StatusParkingSlot;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ParkingSlotUpdateRequest {
	@NotNull
	private String parkingSlotId;
	private String area;
	private String name;
	private Double pricePerHour;
	private StatusParkingSlot parking_Slot_Status;
	private String vehicleCategory;

}