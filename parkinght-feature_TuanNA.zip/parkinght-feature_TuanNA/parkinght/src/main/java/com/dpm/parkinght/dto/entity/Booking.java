package com.dpm.parkinght.dto.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.dpm.parkinght.enums.StatusBooking;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "tbl_booking")
public class Booking {
	@Id
	@Column(name = "booking_id")
	String booking_Id;

//	@Column(name = "user_id")
//	String user_Id;

//	@Column(name = "vehicle_id")
//	String vehicle_Id;

	@Column(name = "start_date")
	LocalDateTime start_Date;

	@Column(name = "end_date")
	LocalDateTime end_Date;

	@Column(name = "create_Date")
	@CreationTimestamp
	LocalDateTime create_Date;

//	@Column(name = "parking_slot_id")
//	String parking_Slot_Id;

	@Column(name = "booking_status")
	StatusBooking booking_Status;

	@Column(name = "update_time")
	@UpdateTimestamp
	LocalDateTime update_Time;

	@Column(name = "booking_total")
	Long booking_Total;
	
	@OneToOne
	@JoinColumn(name = "user_id", nullable = false)
	private User user;

	@OneToOne
	@JoinColumn(name = "parking_slot_id", nullable = false)
	private ParkingSlot parkingSlot;

	@ManyToOne
	@JoinColumn(name = "vehicle_id")
	@EqualsAndHashCode.Exclude
	@ToString.Exclude
	@JsonIgnoreProperties(value = { "vehicleCategory", "user", "report", "booking" })
	private Vehicle vehicle;
	
	@Column(name = "checkinTime")
	LocalDateTime checkin_Time;
	
	@Column(name = "checkoutTime")
	LocalDateTime checkout_Time;
}
