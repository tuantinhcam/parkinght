
//package com.dpm.parkinght.common.handler;
//
//import lombok.AllArgsConstructor;
//import lombok.Builder;
//import lombok.Data;
//
//
//@Data
//@Builder
////@AllArgsConstructor
//public class ErrorMessage {
//    private final int code;
//    private final String message;
//	public int getCode() {
//		return code;
//	}
//	public String getMessage() {
//		return message;
//	}
//	public ErrorMessage(int code, String message) {
//		this.code = code;
//		this.message = message;
//	}
//
//}