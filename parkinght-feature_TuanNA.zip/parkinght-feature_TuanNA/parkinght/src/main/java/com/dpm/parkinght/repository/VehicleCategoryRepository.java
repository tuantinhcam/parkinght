package com.dpm.parkinght.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dpm.parkinght.dto.entity.VehicleCategory;


public interface VehicleCategoryRepository extends JpaRepository<VehicleCategory, String> {
	VehicleCategory findAllByVehicleCategoryName(String name);

	List<VehicleCategory> findAllByDelFlag(boolean delFlag);
}