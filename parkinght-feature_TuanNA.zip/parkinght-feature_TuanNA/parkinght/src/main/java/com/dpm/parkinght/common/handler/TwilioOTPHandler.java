//package com.dpm.parkinght.common.handler;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.stereotype.Component;
//import org.springframework.web.reactive.function.BodyInserters;
//import org.springframework.web.reactive.function.server.ServerRequest;
//import org.springframework.web.reactive.function.server.ServerResponse;
//
//import com.dpm.parkinght.dto.request.OTPSendRequest;
//import com.dpm.parkinght.service.OTPTwilioService;
//
//import reactor.core.publisher.Mono;
//
//@Component
//public class TwilioOTPHandler {
//
//	@Autowired
//	private OTPTwilioService twilioService;
//	
//	public Mono<ServerResponse> sendOTP(ServerRequest serverReq){
//		return serverReq.bodyToMono(OTPSendRequest.class)
//				.flatMap(dto->twilioService.sendOTPResetPassword(dto))
//				.flatMap(dto->ServerResponse.status(HttpStatus.OK)
//				.body(BodyInserters.fromValue(dto)));
//	}
//	public Mono<ServerResponse> validateOTP(ServerRequest serverReq){
//		return serverReq.bodyToMono(OTPSendRequest.class)
//				.flatMap(dto->twilioService.validateOTP(dto.getOtp(), dto.getDestPhoneNumber()))
//				.flatMap(dto->ServerResponse.status(HttpStatus.OK)
//				.bodyValue(dto));
//	}
//}
