package com.dpm.parkinght.service.impl;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dpm.parkinght.common.GetNotNull;
import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.dto.entity.VehicleCategory;
import com.dpm.parkinght.dto.request.VehicleCategoryCreateRequest;
import com.dpm.parkinght.mapper.VehicleCategoryMapper;
import com.dpm.parkinght.repository.UserRepository;
import com.dpm.parkinght.repository.VehicleCategoryRepository;
import com.dpm.parkinght.service.UserService;
import com.dpm.parkinght.service.VehicleCategoryService;

@Service
//@RequiredArgsConstructor
public class VehicleCategoryServiceImpl implements VehicleCategoryService {

	// @Autowired
	private final VehicleCategoryRepository vehicleCategoryRepository;
	private final UserRepository userRepository;
	private final UserService userService;

	@Autowired
	public VehicleCategoryServiceImpl(VehicleCategoryRepository vehicleCategoryRepository,
			UserRepository userRepository, UserService userService) {
		this.vehicleCategoryRepository = vehicleCategoryRepository;
		this.userRepository = userRepository;
		this.userService = userService;
	}

	@Override
	public List<VehicleCategory> getAll(Principal principal) {
		if (userService.isDriver(principal.getName())) {
			// driver view ban ghi chua xoa
			return vehicleCategoryRepository.findAllByDelFlag(false);
		} else {
			// admin+manager view all
			return vehicleCategoryRepository.findAll();
		}
	}

	@Override
	public VehicleCategory save(VehicleCategoryCreateRequest request, Principal principal) {
		if (userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		VehicleCategory vehicleCategory = VehicleCategoryMapper.convertToCategoryResponse(request);
		if ("".equals(vehicleCategory.getVehicleCategoryName()) || vehicleCategory.getVehicleCategoryName() == null) {
			throw new LogicException("Vehicle Category name is not null");
		} else if (vehicleCategory.getVehicleCategoryName().length() > 30) {
			throw new LogicException("Vehicle Category name is too long");
		}
		// check trung name
		VehicleCategory checkByName = findByName(request.getVehicleCategoryName());
		if (checkByName != null) {
			throw new LogicException("Loại xe này đã có!");
		}
		return vehicleCategoryRepository.save(vehicleCategory);
	}

	@Override
	public VehicleCategory findById(Principal principal, String id) {
		VehicleCategory vehicleCategory = vehicleCategoryRepository.findById(id)
				.orElseThrow(() -> new LogicException("Not found vehicle category with id: " + id));
		if (userService.isDriver(principal.getName())) {
			if (vehicleCategory.getDelFlag()) {
				throw new LogicException("Not found vehicle category with id: " + id);
			}
		}
		return vehicleCategory;
	}

	@Override
	public VehicleCategory deleteVehicleCategory(String id, Principal principal) {
		if (userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		VehicleCategory vehicleCategory = findById(principal, id);
		vehicleCategory.setUpdateTime(LocalDateTime.now());
		vehicleCategory.setDelFlag(true);
		vehicleCategory.setDelDate(LocalDateTime.now());
		vehicleCategory.setDelUserId("user");
		Optional<User> user = userRepository.findByPhoneNumber(principal.getName());
		vehicleCategory.setDelUserId(user.get().getUserId());
		return vehicleCategoryRepository.save(vehicleCategory);
	}

	@Override
	public VehicleCategory update(VehicleCategory vehicleCategory, Principal principal) {
		if (userService.isDriver(principal.getName())) {
			throw new LogicException("Not permission");
		}
		if (vehicleCategory.getVehicleCategoryName().length() > 30) {
			throw new LogicException("Vehicle Category name is too long");
		} // check trung name
		VehicleCategory checkByName = findByName(vehicleCategory.getVehicleCategoryName());
		if (checkByName != null) {
			throw new LogicException("Loại xe này đã có!");
		}
		VehicleCategory category = findById(principal, vehicleCategory.getVehicleCategoryId());
		BeanUtils.copyProperties(vehicleCategory, category, GetNotNull.getNullPropertyNames(vehicleCategory));
		category.setUpdateTime(LocalDateTime.now());
		return vehicleCategoryRepository.save(category);
	}

	@Override
	public VehicleCategory findByName(String name) {
		if (GetNotNull.isNull(name)) {
			throw new LogicException("Vehicle Category Name is not null");
		}
		return vehicleCategoryRepository.findAllByVehicleCategoryName(name);
	}
}
