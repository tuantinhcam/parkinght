package com.dpm.parkinght.mapper;

import java.time.LocalDateTime;
import java.util.UUID;

//import org.modelmapper.ModelMapper;

import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.dto.entity.Vehicle;
import com.dpm.parkinght.dto.request.VehicleCreateRequest;

public class VehicleMapper {
    //private static final ModelMapper modelMapper = new ModelMapper();

    public static Vehicle convertToVehicle(VehicleCreateRequest request) { //create vehicle
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(UUID.randomUUID().toString());
        String plateNumber = request.getPlateNumber();
        if (plateNumber.length() > 15 || plateNumber.length() < 8) {
            throw new LogicException("Biển số xe lớn hơn 8 và nhỏ hơn hoặc bằng 15 ký tự");
        }
        vehicle.setPlateNumber(plateNumber);
        vehicle.setVehicleName(request.getVehicleName());
        vehicle.setNumberOfFouls(0);
        vehicle.setUpdateTime(LocalDateTime.now());
        vehicle.setDelFlag(false);
        vehicle.setDelDate(null);
        vehicle.setDelUserId(null);
        return vehicle;
    }
}
