package com.dpm.parkinght.service.impl;

import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.config.UserInfoDetails;
import com.dpm.parkinght.dto.entity.User;
import com.dpm.parkinght.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
//@Lazy
public class UserInfoServiceImpl implements UserDetailsService {
	// @Autowired
	private final UserRepository userRepository;

	// @Autowired
	private final PasswordEncoder encoder;

	@Autowired
	@Lazy
	public UserInfoServiceImpl(UserRepository userRepository, PasswordEncoder encoder) {
		this.userRepository = userRepository;
		this.encoder = encoder;
	}

//    public UserInfoServiceImpl() {
////		super();
//	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> userDetail = userRepository.findByPhoneNumber(username);

		// Converting userDetail to UserDetails
		return userDetail.map(UserInfoDetails::new)
				.orElseThrow(() -> new UsernameNotFoundException("User not found " + username));
	}

	public String addUser(User userInfo) {
		userInfo.setPassword(encoder.encode(userInfo.getPassword()));
		userRepository.save(userInfo);
		return "User Added Successfully";
	}

	public User findByPhoneNumber(String phoneNumber) {
		return userRepository.findByPhoneNumber(phoneNumber).orElseThrow(() -> new LogicException("Bad request"));
	}
}
