package com.dpm.parkinght.controller;

import com.dpm.parkinght.common.BaseResponse;
import com.dpm.parkinght.common.errors.LogicException;
import com.dpm.parkinght.dto.entity.Report;
import com.dpm.parkinght.dto.request.ReportCreateRequest;
import com.dpm.parkinght.dto.request.ReportUpdateRequest;
import com.dpm.parkinght.service.ReportService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/report")
public class ReportController {
    private final ReportService reportService;

    @Autowired
    public ReportController(ReportService reportService) {
        this.reportService = reportService;

    }

    @GetMapping("/get-all")
    public BaseResponse<List<Report>> getAll(Principal principal) {
        return BaseResponse.ok(reportService.getAll(principal));
    }

    @GetMapping("/get-unread/{id}")
    public BaseResponse<List<Report>> getUnreadReport(Principal principal, @PathVariable("id") Integer isRead) {
        Integer isReadStatus = 0;
        try {
            isReadStatus = Integer.parseInt(isRead.toString());

        } catch (Exception e) {
            throw new LogicException("Vui long nhap trang thai da xem report hoac chua xem report");
        }
        return BaseResponse.ok(reportService.getUnreadReport(principal, isReadStatus));
    }
    @GetMapping("/get-count-unread/{id}")
    public BaseResponse<?> getCountUnreadReport(Principal principal, @PathVariable("id") Integer isRead) {
        Integer isReadStatus = 0;
        try {
            isReadStatus = Integer.parseInt(isRead.toString());

        } catch (Exception e) {
            throw new LogicException("Vui long nhap trang thai da xem report hoac chua xem report");
        }
        return BaseResponse.ok(reportService.countUnreadReport(principal, isReadStatus));
    }

    @PostMapping("/create")
    public BaseResponse<?> createReport(@Valid @RequestBody ReportCreateRequest request, Principal principal) {
        return BaseResponse.ok(reportService.save(request, principal));
    }

    @GetMapping("/get-by-id/{id}")
    public BaseResponse<?> getById(@PathVariable("id") String id) {
        return BaseResponse.ok(reportService.findById(id));
    }

    @PutMapping("/update")
    public BaseResponse<?> update(Principal principal, @RequestBody ReportUpdateRequest reportUpdateRequest) {
        return BaseResponse.ok(reportService.update(principal, reportUpdateRequest));
    }

    @GetMapping("/get-by-driver")
    public BaseResponse<?> getByDriver(Principal principal) {
        return BaseResponse.ok(reportService.getReportByDriver(principal));
    }

}