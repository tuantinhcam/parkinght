package com.dpm.parkinght.dto.response;

import com.dpm.parkinght.enums.StatusOTP;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OTPResponse {

	private StatusOTP status;
	private String code;
	private String message;
}
