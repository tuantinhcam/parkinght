package com.dpm.parkinght.enums;

public enum StatusOTP {
	DELIVERED,
	FAILED
}
