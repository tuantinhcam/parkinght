package com.dpm.parkinght.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dpm.parkinght.common.BaseResponse;
import com.dpm.parkinght.dto.entity.ParkingSlot;
import com.dpm.parkinght.dto.request.ParkingSlotCreateRequest;
import com.dpm.parkinght.dto.request.ParkingSlotUpdateRequest;
import com.dpm.parkinght.service.ParkingSlotService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/parking-slot")
public class ParkingSlotController {
	@Autowired
	private ParkingSlotService parkingSlotService;

	@GetMapping("/get-all")
	public BaseResponse<List<ParkingSlot>> getAll(Principal principal) {
		return BaseResponse.ok(parkingSlotService.getAll(principal));
	}

	@PostMapping("/create")
	public BaseResponse<?> createVehicle(@Valid @RequestBody ParkingSlotCreateRequest request, Principal principal) {
		return BaseResponse.ok(parkingSlotService.save(request, principal));
	}

	@GetMapping("/get-by-id/{id}")
	public BaseResponse<?> getById(Principal principal, @PathVariable("id") String id) {
		return BaseResponse.ok(parkingSlotService.findById(principal, id));
	}

	@GetMapping("/get-by-area/{area}")
	public BaseResponse<?> getByArea(Principal principal, @PathVariable("area") String area) {
		return BaseResponse.ok(parkingSlotService.findByArea(principal, area));
	}

	@PutMapping("/delete/{id}")
	public BaseResponse<?> delete(@PathVariable("id") String id, Principal principal) {
		return BaseResponse.ok(parkingSlotService.deleteParkingSlot(id, principal));
	}

	@PutMapping("/update")
	public BaseResponse<?> update(@Valid @RequestBody ParkingSlotUpdateRequest request, Principal principal) {
		return BaseResponse.ok(parkingSlotService.update(request, principal));
	}

	@GetMapping("/get-all-area")
	public BaseResponse<?> getAllArea(Principal principal) {
		return BaseResponse.ok(parkingSlotService.findAllArea(principal));
	}


}
