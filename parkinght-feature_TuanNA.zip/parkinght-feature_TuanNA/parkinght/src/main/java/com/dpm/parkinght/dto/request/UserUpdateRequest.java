package com.dpm.parkinght.dto.request;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserUpdateRequest {
	private String userId;
    private String fullName;
    private Date birthday;
    private String email;

	
}
